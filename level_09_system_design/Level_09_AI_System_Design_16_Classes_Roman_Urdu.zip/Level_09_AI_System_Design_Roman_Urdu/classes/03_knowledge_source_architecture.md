# Class 03 — Knowledge sources, memory, freshness aur provenance
**Module:** M9.2 · **Session:** 3/16 · **Reference:** *AI Engineering* Ch 6 + Ch 10

## Goal
Aap decide kar sakein ke **model knowledge vs prompt context vs RAG vs durable memory vs external tools** mein se kis information ko kahan rakhna hai.

## 1) Knowledge is not one database
**Model parameters** training se general patterns/knowledge retain karte hain. **System instructions** application ka behavior set karte hain. **Context window** temporary working input hai. **RAG** trusted document chunks dynamically fetch karta hai. **Memory/state** long-term user facts ya current workflow progress store kar sakti hai. **Tools** live authoritative truth (e.g., current balance) la sakte hain.

| Information | Preferred source | Kyun |
|---|---|---|
| General grammar and prose | Model capabilities | Stable, retrieval overhead not necessary |
| Company handbook | Versioned RAG repository | Changes + attribution + permissions |
| Customer order status | Authenticated order API | Real-time source of truth |
| User's selected language | Scoped preference store / consented memory | Persistent yet user-specific |
| Session's current step | Workflow state/checkpointer | Resumable, deterministic |
| Company policy on refunds | RAG + backend rules for enforcement | Text explanation != transaction authority |

**Critical principle:** Retrieval result ko model apne answer mein use kar sakta hai, lekin policy enforcement backend rules and auth se hona chahiye, not prompt instructions alone.

## 2) Context vs memory vs source of truth
- **Context:** abhi model ko jo tokens diye ja rahe hain. Ephemeral; cost + context limit.
- **Short-term state:** conversation/messages, approved steps; per-session/thread isolation.
- **Long-term memory:** intentionally persisted user/project info; needs consent, retention, deletion, access checks; not automatically reliable truth.
- **Source of truth:** authorized system (database, HR system, ticket service). Memory aur cached LLM answer is ka substitute nahi.

**Example:** User kehta hai "My order is shipped". User statement is claim. Backend status is authoritative record. Agar conflict aaye, model ko user claim ko official status samajh kar answer nahi dena chahiye.

## 3) Freshness architecture
Docs update = new source version → parse → chunk → index → retrieve current version. Ismein **eventual consistency window** ho sakti hai. Product requirements set karein ke policy change kitni der mein search results tak aana chahiye. "Instantly updated" claim tab tak na karo jab tak update pipeline measured na ho.

```mermaid
flowchart LR
 A[Approved docs] --> B[Version + metadata]
 B --> C[Parse and segment]
 C --> D[Keyword / vector indexes]
 D --> E[Query-time retrieval]
 F[Identity + tenant] --> E
 E --> G[Context with citations]
 G --> H[LLM]
```

**Delete handling:** Source delete hone par index aur cached results invalidate; deletion obligation ho to logs/archives retention rules bhi handle karo. **Temporal validity:** "Effective from" and "supersedes" fields support conflicting versions.

## 4) Provenance = jawab kahan se aaya?
Sirf "Source: handbook" weak evidence. Ideal citation fields: document ID, immutable version, title, section, effective date, permitted source URL/fragment, retrieved timestamp. Generate answer ke baad citation-to-claim check: kya actual cited text statement support karta hai? Model fabricated URL invent kar sakta hai; actual source refs backend se map karo.

## 5) Data access control
Multi-tenant SaaS mein retrieval scope before ranking: **tenant_id + allowed docs + record-level permissions** enforce. Vector similarity permission nahi hoti. Unauthorized chunks prompt tak nahi pohanchne chahiye. Cache key mein tenant/user/authorization scope include karo; permission change se invalidation karo.

## 6) Dynamic retrieval vs always-on context
**Always-on:** concise system rules, output schema, current task objective. **On demand:** large policies, private files, customer records, time-changing facts. **External durable state:** conversation checkpoint, approved actions, audit trail. Agar 200-page handbook har query ke saath bhejo ge to token cost, latency, distraction barhegi.

## 7) Common mistakes
- Untrusted document text ko system instruction ka authority dena.
- User memory ko account source of truth banana.
- Policy update ke baad old vector chunks serve karna.
- Source permission checks **after** LLM response karna.
- Retrieved chunk mein source/version metadata omit karna.

## Exercise
Healthcare-adjacent appointment scheduling assistant (medical advice nahi): booking slots, clinic visiting hours, user language preference, appointment confirmation — har cheez ka source decide karo aur data retention/security risk likho.

### Self-check
Slots: live scheduling API; visiting hours: versioned content or official API; language: consented preference; confirmation: transaction database, not model memory. Protected/private details per-user auth; action success verify only after booking API confirms.

**Next:** Ingestion se retrieval aur context assembly tak full pipeline design.
