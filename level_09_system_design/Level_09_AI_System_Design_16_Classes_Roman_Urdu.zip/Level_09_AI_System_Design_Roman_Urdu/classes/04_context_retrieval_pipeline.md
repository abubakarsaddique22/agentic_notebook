# Class 04 — Full context pipeline: ingestion, retrieval, reranking, ACL
**Module:** M9.2 · **Session:** 4/16 · **Reference:** *AI Engineering* Ch 6; Ch 4 for evaluation

## Outcome
Aap scalable **ingestion → retrieval → reranking → context assembly → generation** architecture design karenge aur hybrid retrieval / ACL / source freshness trade-offs justify karenge.

## 1) Offline indexing aur online answering separate karo
**Offline ingestion:** document event → format parsing → quality validation → segmentation/chunking → embeddings/term index → version metadata → publish. **Online query:** authenticate → intent → secure filter → lexical/semantic retrieval → merge/deduplicate → rerank → token-budget pack → grounded answer.

```mermaid
flowchart TB
 subgraph Indexing[Async ingestion path]
 D[Documents] --> P[Parse, clean, de-duplicate]
 P --> V[Chunks + tenant/version/ACL]
 V --> I[(Vector + keyword index)]
 end
 subgraph Query[Online low-latency path]
 U[User] --> A[Auth + policy scope]
 A --> R[Hybrid retrieve]
 I --> R
 R --> N[Rerank + remove duplicates]
 N --> C[Assemble bounded context]
 C --> L[LLM]
 L --> O[Grounding + citations check]
 end
```

## 2) Chunk strategy is architecture decision
- **Too small:** isolated sentences context lose; retrieved evidence incomplete.
- **Too large:** noise + token cost + truncation; similarity coarse.
- **Structured chunking:** headings, sections, tables, code symbols, parent-child relation preserve.
- **Overlapping chunks:** boundaries par useful, lekin index size and duplicate passages increase.
- **Metadata:** source version, section, tenant, ACL, updated_at, effective_at; never treat embedding alone as access policy.

Chunk size universal "best" nahi. **Question set** par retrieval recall aur grounded answer quality evaluate karke choose karo.

## 3) Retrieval variants
| Approach | Useful for | Weakness |
|---|---|---|
| Keyword/BM25 | IDs, exact technical terms, names | Synonyms/semantic phrasing |
| Dense vector | Paraphrase, concept matching | Exact IDs aur numerics sometimes miss |
| Hybrid | Exact + meaning together | Score fusion/tuning complexity |
| Graph-assisted | Multi-hop relationships, entities | Graph maintenance, cost, design burden |
| Metadata filter | Tenant/date/document type constraints | Misconfigured filters can remove relevant data |

**Fusion:** lexical and dense results combine; scores raw comparable nahi, so rank-based fusion ya calibrated weights consider; reranker expensive ho sakta hai but quality improve when candidates noisy.

## 4) Retrieval quality and end-to-end quality alag hain
- **Recall@k:** required evidence top-k set mein included?
- **Precision@k:** retrieved items kitne actually relevant?
- **MRR/nDCG:** relevant evidence ranking quality.
- **Grounded answer correctness:** model ne evidence sahi use kiya?

Example: top-5 mein correct policy present hai phir bhi model outdated clause choose kare, to **retrieval success, generation failure**. Dono stages ko separately observe karo. Gold labels manually curated examples se banayein.

## 5) Context packing
Query ko 15 chunks milay. Token budget 4k hai. Pack karein **relevance × access eligibility × diversity × version/currentness**, avoid duplicates; always source IDs and section metadata include. Conflicting dates par model ko uncertainty express karne dein. Retrieval score model confidence ka direct probability nahi.

## 6) Retrieval failure mode matrix
| Failure | Detection | Response |
|---|---|---|
| Relevant doc absent | Recall eval / no matches | Request clarification or safe handoff |
| Stale version | Source-version mismatch | Invalidate index/cache, restrict answer |
| Unauthorized chunk | ACL audit test | Block before model, incident alert |
| Prompt injection in document | Source trust classification | Treat as quoted data not instructions |
| Too much evidence | Token overflow / relevance drops | Rerank/pack smaller context |
| Citation not supported | Claim-evidence check | Revise/abstain/escalate |

## 7) Real-world design judgment
Employee handbook + org-wide search: hybrid retrieval often pragmatic. Customer balances: backend DB/authorized API not embeddings. Complex related legal entities: graph retrieval **only if evaluation proves multi-hop need**. Avoid graph-first tech enthusiasm.

## Exercise
A support chatbot fails on product IDs such as `SKU-5008` but succeeds on general questions. Dense search already running. Architect ka action plan kya hoga?

### Worked reasoning
First reproduce failures in labeled eval set; inspect chunking/token normalization and exact ID indexing; add lexical/BM25 or exact-field lookup and merge results; validate tenancy and version; compare before/after recall and latency. Immediately switching to a larger LLM would not fix missing evidence.

**Next:** Model gateway aur routing.
