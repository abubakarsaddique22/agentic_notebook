# Class 12 — AI pipeline orchestration: workflows, agents, async jobs
**Module:** M9.7 · **Session:** 12/16 · **Book:** *AI Engineering* Ch 6, Ch 10

## Goal
Aap decide karenge ke **deterministic DAG**, bounded tool-using agent, background job, event/queue, state machine ya synchronous API kab use karni hai; component boundaries clear hon.

## 1) Orchestration ka simple matlab
AI application mein retrieval, model calls, validators, tools, caching, permissions, human approval — sab **kis order mein aur kis policy ke tehat** execute hon? Ye orchestration hai. One orchestrator everything store kare to bottleneck; orchestration is control flow, not automatically source of truth.

## 2) Deterministic vs delegated decisions
**Deterministic (rule engine):** Can user access doc? Is amount above threshold? Did output match schema? Has user explicitly confirmed? Is retry safe? **Model delegated:** Which of allowed research topics to investigate first? How to summarize retrieved evidence? Which permitted read-only tool to request when user intent ambiguous?

Rule of thumb: *Irreversible decisions, identity and money = server rules.* Model can help interpret, but backend validates.

```mermaid
flowchart TD
 A[Request] --> B{Small defined task?}
 B -->|Yes| C[Deterministic workflow]
 B -->|No: planning needed| D[Bounded agent planner]
 D --> E[Allowed tool calls + limits]
 E --> F[Tool results + state]
 F --> G{Objective complete / budget?}
 G -->|Continue permitted| D
 G -->|Stop| H[Final validation or handoff]
 C --> H
```

## 3) Sync vs async vs queued
| Pattern | Use when | UX and reliability |
|---|---|---|
| Synchronous | Short query, immediate response required | Deadline/streaming; strict timeouts |
| Async background job | Deep research/report > interactive budget | Job ID, status, cancel, eventual completion |
| Queue/event-driven | Bulk ingestion, embeddings, notifications | Durable events, retries, DLQ, observability |
| Long-running workflow | Human approval, multi-stage booking | Durable state, resume, idempotency |

**Async isn't free:** job status persistence, duplicate delivery, cancel semantics, expiration, retention, stuck-job alert necessary.

## 4) Tool contracts and state
Each component defined inputs, outputs, error classes, timeout, ownership, observability, idempotency, data sensitivity. "RAG service" should return passages with source IDs + access scope; "Business API" should report authoritative transaction status; LLM output should be untrusted until schema validation.

**State:** session/thread state for conversation; durable workflow state for multi-step task; separate user profile memory; avoid mixing private user data across tenants or sessions.

## 5) Agent budgets
Agent may repeatedly search; cap tool-call count, elapsed time, context size, allowed domains, read vs write privileges, $ budget, maximum steps. Set explicit stop conditions and escalation. High reasoning flexibility increases testing surface; task must actually need it.

## 6) Failure and compensation
Multi-step workflow fails after step 2: know which operations were committed. If reversible, compensating action may be used, but compensation itself may fail. Keep durable execution log; no silent assumption of atomicity across unrelated external APIs.

## 7) Example support orchestration
Intent classifier routes: (a) FAQ → scoped RAG → cite answer; (b) order status → auth → live API → format result; (c) change/cancel → proposal → policy validation → user approval → transaction verify; (d) unhandled → human. No general agent needed for most flows.

## Practice
"Generate a 20-page company risk report every Monday" vs "Check my order now" vs "Request refund approval" — select control flow, identity, state and failure recovery.

### Suggested answer
Report: scheduled async job, retrieval provenance and review, persisted status + output; order: short sync authorized tool; refund: durable workflow with explicit approval and idempotent write. All use component-specific timeouts and traces.

**Next:** Production observation and feedback loop.
