# Class 16 — Capstone: Complete AI System Design Document
**Module:** M9.10 · **Session:** 16/16 · **Book:** *AI Engineering* Ch 10 (architecture and feedback), cross-references Ch 4/6/9

> **Purpose:** Ye ek **fully worked fictional system design** hai. Isay copy karke apna idea replace karein. All traffic, cost, SLO, and model capability figures below **illustrative assumptions**, verified vendor benchmarks ya production claims nahi. Model/provider names deliberately abstract hain: capability first.

# Part A — Example design document

## 1. Problem statement
**Product:** Acme Multi-Tenant Support Intelligence Platform. Customers ko company-approved docs se **source-linked** answers chahiye; logged-in customers apne orders ka live status dekh sakein; customer support agents escalated tickets receive karein; future mein limited authorized refunds with explicit human approval.

**Business value hypothesis:** verified customer issue resolution ko improve karna aur agents ka repetitive workload kam karna. Success ka proof measured resolution plus safety, not just chat completion count.

## 2. Scope
### In scope (phase 1)
- Authenticated/anonymous public help answers; private answers only logged-in.
- Scoped latest product policies with actual evidence citations.
- User-authorized live order-status reads; human handoff for exceptions.
- Monitoring, offline evaluation, safe logs and versioned rollout.

### Out of scope (phase 1)
- Autonomous refunds, cancellation, payments, account deletion.
- Unrestricted browsing or unbounded agents.
- Cross-tenant aggregate disclosure.
- Unverified legal/medical/financial advice.

## 3. Success and guardrail criteria
| Category | Proposed measurable objective | Measurement | Action if breached |
|---|---|---|---|
| Answer quality | ≥90% on curated grounded-answer eval | Human-scored rubric; held-out cases | Stop rollout / inspect failures |
| Evidence | ≥98% of citations support cited claims | Source-level annotated audit | Reject/repair unsupported claims |
| User latency | p95 completed eligible text response ≤6s | E2E production traces at peak | Bottleneck analysis and scale/degrade |
| Availability | ≥99.5% eligible read requests return valid result | Rolling 30-day request SLI | Provider/queue incident response |
| Authorization | Zero known cross-tenant authorized-data exposures | Continuous tests + incidents | Security incident / block affected path |
| Operational cost | Target ≤$0.03 per *resolved* AI-supported issue | Cost allocation + real resolution | Route/cache/evaluate alternatives |
| Escalation | High-risk/unknown cases reach a human | Reviewed escalation sample | Adjust policy + staffing |

Targets **proposed assumptions**; actual thresholds require business/privacy sign-off. Threshold met does not certify safe system; severity-weighted incidents matter.

## 4. Users, workload and traffic
Assume 60,000 user queries/day, 20 tenants, peak 18 QPS, growing 3× annually, average 2,200 input and 300 generated output tokens per model-call; 15% requests tool-only, 20% of remaining model-call-eligible requests safely cached, 8% generated attempts rerun (example simplified approximation).

**Average inbound QPS:** 60,000/86,400 ≈ **0.694 req/s**; 18 QPS peak is a strong burst assumption. Request size and workloads vary by tenant. **Do not equate** 18 peak QPS to average model demand.

**A rough model-call count:** eligible model-dependent requests = 60,000 × 0.85 = 51,000/day. Cache miss = 51,000 × 0.80 = **40,800 initial generated completions/day**. If 8% of generated completions cause one additional attempt, add 3,264 model calls → **44,064 completions/day** (assumes no retry cascades and no extra LLM judge calls).

**Token estimate under these assumptions:** 44,064 × 2,200 = **96,940,800 input tokens/day**; 44,064 × 300 = **13,219,200 output tokens/day**. Tool costs, indexing, storage, human reviews, gateway, rerank, extra evaluation calls excluded.

**Hypothetical pricing only:** Suppose $1 / million input and $4 / million output tokens. Model spend/day ≈ $96.94 + $52.88 = **$149.82/day**; 30-day ≈ $4,494.53 at identical workload, without infrastructure, storage, retries beyond assumed, and provider fees. **Never treat this as actual current price or total TCO.**

## 5. High-level architecture
```mermaid
flowchart TD
 U[Web / chat UI] --> A[API auth + request admission]
 A --> B[Policy / intent router]
 B -->|Knowledge question| C[Retrieval orchestrator]
 B -->|Order inquiry| T[Authorized order-service read]
 C --> D[ACL scoped hybrid search]
 D --> E[Rerank and citation-pack]
 E --> G[Answer model gateway]
 T --> G
 B -->|Human needed| H[Support ticket queue]
 G --> V[Schema, evidence and PII validations]
 V -->|Valid| O[Answer + sources]
 V -->|Unclear| H
 A --> M[Metrics, safe logs, traces]
 C --> M
 G --> M
 V --> M
 subgraph Knowledge ingestion
 K[Approved policy sources] --> N[Parse/version/ACL]
 N --> I[(Search indexes)]
 end
 I --> D
 A --> Q[Scoped cache policy]
 Q --> B
```

**Data/control planes:** Online answer path separate from async ingestion/index updates, and both distinct from monitoring/control. Each service has versioned contract and owner. Multi-tenant auth context propagates only through trusted server-side fields. Mermaid is logical, not deployment wiring.

## 6. Model selection + routing
**Baseline:** single approved general LLM for policy Q&A, authorized tool for live status. Benchmark on own 300+ representative prompts (illustrative dataset-size suggestion, not universal minimum). Evaluate model classes instead of committing to brand names:

1. **Small/fast:** short FAQ, simple reformulation; use only if measured answer reliability meets rubric.
2. **Stronger:** ambiguous policy comparisons, complicated synthesis, sensitive cases with tighter quality checks.
3. **No LLM:** exact live status and deterministic policy checks where natural-language generation unnecessary.
4. **Provider fallback:** pre-approved region, capability, output schema, security eval, audited switch. Fail closed if policy constraint cannot be met.

**Router signals:** task type, severity, tool requirement, language, context size, tenant residency, observed model quality, remaining request budget. Track route/version for every evaluated response.

## 7. Context and RAG architecture
**Ingestion:** Source document connector → immutable version + effective date → parse normal headings/tables → chunk with parent metadata → keyword and embedding indexes → canary publish/quality validation → flip active index pointer. Hard delete + outdated version invalidation supported.

**Query-time:** authorize tenant and roles → metadata-filtered lexical/vector retrieval → fuse and rerank → diversify evidence → pack citations/source refs into bounded context → model generate → claim-to-citation check. No evidence = explicit uncertainty/handoff.

**Non-RAG:** Live order status always from verified authorized order API; accounts and balances never treated as answerable from general text chunks. User preferences held in consented, scoped store and deleted on request where policy requires.

## 8. Tool/agent architecture
Phase 1 mostly deterministic routing; **not** default autonomous agent. Read-only tools have server-side ACL and structured outputs. Future write flow:

```mermaid
flowchart LR
 A[Model drafts request] --> B[Backend auth + eligibility]
 B --> C[Human sees exact action]
 C -->|Approves| D[Idempotent transaction API]
 C -->|Rejects| E[No write]
 D --> F[Verify, audit, notify]
```

Approval binds action+parameters+actor+expiry; new params require reapproval. No financial action based on untrusted document instructions.

## 9. Caching strategy
| Cache | Policy | Invalidation |
|---|---|---|
| Public FAQ exact | Eligible static answer; version key | Source version + TTL |
| Tenant-scoped FAQ semantic | Only validated equivalent intents, ACL keys | Doc/prompt/model version + TTL |
| Retrieval result | Tenant+permissions+index version | Re-index and access policy changes |
| Prompt prefix cache | Stable instruction prefix via provider feature, where approved | Prefix/config/provider semantics |
| Order status | No shared generated response cache | Always authoritative API unless separately approved freshness SLA |

Cache hit rate separately for eligible traffic; stale-citation incidents and wrong-user exposure are hard failure signals. Cache eviction + stampede protection; quality gate before caching.

## 10. Latency budget and capacity
**Illustrative 6s sequential allowance:** network/auth 0.35s; routing+cache 0.25s; retrieval/rerank 0.95s; prompt assembly 0.20s; model TTFT 1.0s; generation 2.65s; validation 0.60s = **6.0s**. Fast paths without retrieval differ, live tool paths differ. Actual p95 must be measured from production-like load rather than adding per-stage p95.

**Scaling priorities:** horizontally scalable stateless API and retrieval gateway; separate ingestion worker autoscaling; provider TPM/RPM limit checks; bounded queues, admission control and tenant fairness; model/region capacity monitoring. Peak retries may amplify load. Load test realistic input/output tokens and concurrency; track *goodput* within SLO.

## 11. Reliability and fallback
| Failure | Trigger | Response | Detection |
|---|---|---|---|
| Model provider unavailable | 429/5xx, timeout | Bounded retry; pre-evaluated approved fallback; or human | Error spike, route alert |
| Search index stale | Lag/version mismatch | Skip unsupported claim; use approved latest source, otherwise escalate | Freshness SLI |
| User not authorized | Missing/invalid identity | Deny private retrieval and tools | Access audit |
| Live API timeout | Unknown transaction/read status | Clearly indicate unavailable; do not guess | Tool success/timeout traces |
| Validation fails | Invalid schema/citation | One bounded repair or abstain | Validation failure counts |
| Traffic surge | Queue p95 exceeds budget | Rate limits, load shedding, public-only safe path | Queue depth, p95 alerts |
| Human queue overloaded | Escalations unresolved | Communicate case status, support SLO, add capacity | Backlog-age alerts |

**Recovery:** Alert on major quality/security regression; kill switch by route/tenant; rollback prompt/index/model version; preserve idempotent state and privacy-safe trace ID for incident analysis.

## 12. Guardrails and privacy
- Server-side auth + row/document-level ACL *before* LLM access.
- Secrets stored in secure credentials system, never client or raw prompts.
- Retrieved text considered **untrusted data**, not tool-execution instruction.
- Validate tool parameters, schema, source citations, structured status fields.
- Suppress unnecessary personal data in logs; audit actions and retention by policy.
- High-impact write requires explicit human approval and transaction verification.
- Red-team test: prompt injection, cross-tenant requests, tool misuse, malicious source URLs, refusal false positives.

## 13. Evaluation and observability
**Pre-production gates:** security policy tests, retrieval labeled recall@k, answer factuality+grounding rubric, citation accuracy, tool contracts, user-task success, p95 at realistic peak, per-accepted-request spend. LLM-based evaluation can supplement but must calibrate using human labels for critical decisions.

**Production telemetry:** request/trace ID; tenant-scoped opaque key; task type; route/model version; source/index version; span timings; token usage; cache decision; validation/error category; user escalation/outcome. Don't log raw protected text by default.

**Feedback loop:** User thumbs-down (explicit) + repeated attempts/escalation (implicit, ambiguous) → staff triage → labeled failures → regression test → controlled change → canary + comparison → rollout/rollback.

## 14. Alternatives considered / ADRs
| Decision | Chosen | Rejected | Reason + revisit trigger |
|---|---|---|---|
| Current policies | Versioned RAG | Fine-tune facts | Freshness/provenance; reconsider if policy rarely changes and quality warrants tuning *style*, not authoritative facts |
| Order status | Authenticated API | Embed order rows into vector store | Live correctness/security; revisit only if authorized system offers better read replica |
| Main task flow | Deterministic router/workflow | Open-ended autonomous agent | Lower complexity + clearer permissions; revisit if multi-step ambiguous tasks become primary |
| Cache | Scope- and version-aware | Global similarity cache | Privacy/staleness; revisit only for verified public evergreen FAQs |
| Model hosting | Approved API initially | Immediate GPU self-host | Scale/ops and reliability uncertainty; revisit with measured volume, data residency, TCO |
| Launch | Staged canary | Full all-tenant release | Safer rollback, detect production regressions |

## 15. Rollout roadmap
- **Phase 0 (readiness):** Requirements, signed risk/data scope, eval dataset, baseline tests.
- **Phase 1 (MVP):** FAQ scoped RAG + source citations; read-only account lookup; human handoff.
- **Phase 2 (hardening):** Gateway/caching/SLIs, testing, error budgets, documented incident runbooks.
- **Phase 3 (optimization):** Evidence-based routing, fine-grained retriever improvements, scaled load experiments.
- **Phase 4 (controlled action):** Opt-in human approval + idempotency only after security review.

Each phase has pass/fail gates, metric baseline and rollback instructions; no assumed timeline here.

## 16. Risks and unknowns
- Unsupported citations despite retrieved evidence → source-to-claim verification.
- Vendor semantic changes and model upgrades → per-model version/canary eval.
- Tenant metadata mistakes → adversarial isolation tests at retrieval and cache.
- Policy updates outside publishing pipeline → change governance & freshness checks.
- Evaluation dataset not representative → sample new languages, tenants, intents.
- Human-review cost spikes → capacity planning and root-cause fixes.

## 17. Executive design defense (interview-ready)
"Main pehle measurable requirements and failure severity define karta hoon. Baseline use karke missing facts ka problem identify karta hoon; policies ke liye versioned ACL-scoped retrieval, live orders ke liye authenticated source-of-truth APIs, complex generation ke liye tested model routing. Caches only safe scopes mein. Strong server-side authorization and human approval irreversible actions par lagta hai. Performance ko trace waterfall and p95 se measure, fallback ko compliance constraints se validate, aur errors ko offline evals mein turn karta hoon. Main rejected alternatives aur revisit criteria bhi document karta hoon."

# Part B — Aapka reusable capstone template

Copy these headings into a new `.md` and apna project design karo:

1. **Problem & user personas:** kaun, kyun, success definition.
2. **Functional / non-functional requirements:** measurable targets, exclusions.
3. **Assumptions and constraints:** source and verification plan.
4. **Volume & capacity:** daily load, peak QPS, token estimates, concurrency.
5. **Baseline architecture:** minimal design + baseline eval results.
6. **High-level Mermaid diagram:** all trust boundaries and dependencies.
7. **Model choice & routing:** capability matrix, fallbacks, privacy checks.
8. **Knowledge/context design:** source of truth, RAG/memory/tools, ACL/freshness.
9. **Tool/action policies:** read/write, approval, idempotency, audit.
10. **Caching:** types, keys, invalidation, metrics, exclusions.
11. **Latency and TCO:** workload-based models, budgets, uncertainty.
12. **Reliability:** failure matrix, queue/retry/fallback, graceful degradation.
13. **Security/guardrails:** trust boundaries, permission tests, human controls.
14. **Monitoring & evaluation:** SLIs, dashboards, versions, feedback loop.
15. **Scaling and rollout:** bottlenecks, canary, rollback, owners.
16. **ADRs + rejected alternatives:** why chosen and when to revisit.
17. **Open questions and launch criteria:** clear decision gate.

# Part C — Final architecture review checklist

- [ ] Requirements specify whose problems, not just "build chatbot".
- [ ] Baseline evaluated on actual representative tasks.
- [ ] Every architecture box answers a stated requirement / failure.
- [ ] Dynamic versus static facts have separate correct sources.
- [ ] Tenant and resource permissions enforced before retrieval/tools/cache.
- [ ] Model route and fallback are pre-evaluated and policy-compliant.
- [ ] p95 end-to-end, peak goodput and cost per successful task defined.
- [ ] Retrieval quality, answer quality and user resolution measured independently.
- [ ] Sensitive actions have confirmation, bounded approval and idempotency.
- [ ] Logs/traces preserve privacy; config/index/model versions traceable.
- [ ] Observability, escalation, rollback and data deletion plan exist.
- [ ] At least 3 rejected alternatives with trade-off/revisit trigger documented.

## Final assignment
Apna original design banao: "Private company knowledge and actions assistant", "WhatsApp customer assistant", "Code assistant" ya "Research agent". 1 architecture diagram, 1 decision table, 1 failure matrix, token-cost estimate, and evaluation policy present karo. Is example ka **content copy kar ke project real batane ke bajaye** apni assumptions explicitly verify karo.

**Level 9 completion:** Is document ko defend kar sako without code. Implementation operations, deployments and alerts ko next Level 10 LLMOps mein deepen kar sakte ho.
