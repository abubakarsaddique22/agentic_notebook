# Class 10 — Failures, retries, timeouts, circuit breakers, queues
**Module:** M9.6 · **Session:** 10/16 · **Book:** *AI Engineering* Ch 10

## Outcome
Aap dependency-by-dependency failure matrix design kar sakte hain aur reliable response strategies choose kar sakte hain, bina silent hallucination ya duplicate writes ke.

## 1) Failure-first architecture
Har external node fail ho sakta hai: LLM 429/500, retrieval timeout, corrupt chunk, payment API partial success, queue overload, malformed JSON, stale document, invalid auth, tool misconfiguration. Reliability means **predictable behavior even when partial system breaks**—not "never fails".

## 2) End-to-end failure tree
```mermaid
flowchart TD
 U[Request] --> A{Auth + budget?}
 A -->|No| X[Reject safely]
 A -->|Yes| B{Retrieval healthy?}
 B -->|Yes| C{Model healthy?}
 B -->|No| H[Explain unavailable / human]
 C -->|Yes| V{Output valid?}
 C -->|No| F[Bounded retry or approved fallback]
 F --> V
 V -->|Yes| OK[Deliver with provenance]
 V -->|No| H
```

## 3) Timeout, retry, backoff ka farq
- **Timeout:** Call kitni der tak wait kare? Overall user deadline ke andar per-step budget.
- **Retry:** Transient failure repeat; only where safe, limited attempts, exponential backoff with jitter.
- **Circuit breaker:** Repeated failing service ko temporary bypass/open to avoid cascading pressure; half-open probes for recovery.
- **Bulkhead:** One tenant or service ke overload ko doosron se isolate.
- **Queue:** Async work smooth kare; bounded queue, expiration and dead-letter strategy necessary.
- **Rate limit:** Fairness, cost and abuse protection at user+tenant+provider level.

**Important:** Timeout result "server ne kuch nahi kiya" ka proof nahi. For payment/order/write calls, caller timeout ke baad action succeed bhi ho sakta hai; retry se double action ho sakta hai. Use **idempotency keys**, transaction status lookup, durable audit.

## 4) Graceful degradation ladder
| Dependency failure | Unsafe idea | Better degraded behavior |
|---|---|---|
| Retrieval down | Model se internal policy guess | Public-only answers or "cannot verify" |
| Account API down | Old cache se balance assert | Status unavailable; human callback |
| Primary LLM down | Any available public model | Approved fallback with pretested capability/privacy |
| Citation checker down | Cite fabricated links | Hold citation claim / human handoff |
| Queue at capacity | Unlimited jobs accepted | Reject/slow admission and clear user status |
| User identity unverified | Model says verified | Do not access restricted systems |

## 5) Error budget and availability
**SLO**: agreed service objective, e.g. 99.5% of authorized read-only requests return verifiably useful result under 7 seconds within rolling period (illustrative). Exclusions and eligibility must be explicit. Reliability objectives often separate **service up** and **answer trustworthy**.

**SLI** examples: valid completion ratio; user-visible p95 completion; retrieval success; external tool success; cross-tenant policy violation count. **SLA** generally customer-facing agreement with remedies, **SLO** internal target; definitions not interchangeable.

## 6) Retry storm warning
Suppose provider degrades and every of 100 requests retries 3 times simultaneously. Load can balloon and worsen outage. Backoff, retry budget, request deadline, limited concurrency, circuit breaker, and alternate path essential. For batch operations, dead letter jobs not silently ignored.

## 7) RTO/RPO intuition
**RTO:** failure ke baad restoration target. **RPO:** acceptable lost persisted state window. Read-only LLM proxy vs transaction execution different expectations. Durable idempotency state/audit logs backup design matter.

## Practice
A booking tool sends request, then times out. UI ko success nahi mila. What should orchestration do?

### Answer framework
Do **not** blindly retry or claim failure. Check booking status using transaction/correlation or idempotency key; if ambiguous, tell user processing status and escalate. Audit exact intent, actor, request time, verified outcome. Do not create duplicate write.

**Next:** Security guardrails, approvals, SLOs.
