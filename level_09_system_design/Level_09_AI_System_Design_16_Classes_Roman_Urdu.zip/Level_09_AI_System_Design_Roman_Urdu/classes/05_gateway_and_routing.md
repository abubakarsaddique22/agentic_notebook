# Class 05 — Model gateway, abstraction aur intelligent routing
**Module:** M9.3 · **Session:** 5/16 · **Book:** *AI Engineering* Ch 10 (Model Router and Gateway), Ch 4 (model selection)

## Outcome
Aap multi-model AI system ka gateway design kar sakte hain jahan **model provider abstraction, authentication, rate-limit tracking, routing aur logging** central ho.

## 1) Gateway vs router: farq samjho
**Gateway** app aur model providers ke darmiyan stable interface: request translation, credentials, safety policies, audit/usage tracking, rate-limit control. **Router** decision logic: is request ko kis model/provider par bhejna chahiye? Routing gateway ke andar ho sakti hai, ya separately. Gateway sirf reverse proxy nahi; abstraction aur governance bhi hai.

```mermaid
flowchart LR
 A[Web and agents] --> B[Internal LLM Gateway]
 B --> C[Auth, budget, policy checks]
 C --> D{Model router}
 D -->|Simple extraction| E[Fast model]
 D -->|Complex reasoning| F[Strong model]
 D -->|Restricted data| G[Approved region / private model]
 E --> H[Normalized response]
 F --> H
 G --> H
 H --> A
 B --> I[Usage, traces, alerts]
```

## 2) Request contract design
Route request ko model-specific field se pehle **logical task contract** mein represent karo: request_id, task_type, model capability requirements, tenant/permission context, max tokens, context length, latency tier, maximum cost, desired output schema, privacy region, and retry/side-effect policy. Sensitive content unnecessarily log na karo.

**Response contract:** output content, structured validation status, model+provider/version, token usage if provider supplies, latency, stop reason, errors, trace ID, and an explicit fallback/route flag. Different providers ki output semantics normalize karte waqt hidden incompatibilities ko document karo.

## 3) Routing policies
- **Task based:** classification, extraction, reasoning, translation, image/audio modality.
- **Risk based:** High-stakes decision → stricter model+human review; unauthorized data → no route.
- **Cost/latency based:** Bound and SLO ke andar appropriate model; cheap != automatically best.
- **Context based:** Required input length/model context window; long-context ability eval karni hoti hai.
- **Data residency:** Approved region or on-prem option; residency requirement routing **hard constraint** hai.
- **Quality based:** Offline calibrated routing policy; route drift track.

## 4) Centralization: useful but not magic
Central gateway benefits: credential rotation, provider switching, centralized rate limits, usage budgets, instrumentation, retry policy. Risks: **single point of failure**, bottleneck, policy conflicts, and feature-lag when new provider capabilities arrive. HA gateway, timeout budgets aur versioning design karo. Gateway itself ko fail-open for data-security checks na banao.

## 5) Routing decision matrix (illustrative)
| Request | Hard requirement | Preferred strategy | Evidence needed |
|---|---|---|---|
| FAQ paraphrase | 2s perceived responsiveness | Fast model with bounded context | FAQ eval pass |
| Quarterly risk summary | Accurate multi-doc synthesis | Stronger synthesis model | Factual/grounding eval |
| Personal financial record | Approved data location | Restricted deployment | Audit, privacy review |
| JSON entity extraction | Stable schema, low cost | Schema-capable small model | Structured-output failure rate |
| Image understanding | Vision input | Multimodal model | Image task evaluation |

Model router ko **model names** se zyada **capabilities and policy constraints** ke saath design karo. Physical model list change ho sakti hai.

## 6) Failure handling at gateway
- Provider 429: bounded backoff + jitter where safe; rate-limit coordination.
- 5xx or network timeout: route alternate after policy/quality revalidation, not blind downgrade.
- Invalid schema: validate and controlled repair/reprompt, not infinite retry.
- Authentication error: alert and fail closed; do not random provider select.
- Request already triggered external write? Gateway retry mechanism ko tool side-effects duplicate nahi karne dene chahiye.

## 7) Governance metrics
Route distribution by task and tenant, cost per successful request, quality by route, p95 delay, fallback frequency, provider error rate, prompt/config version. Per-route offline eval set and production sampled review.

## Common mistakes
- Provider API key frontend mein rakhna.
- Token quota only monthly total pe define karna; burst per-minute limit ignore.
- Cross-region provider fallback without residency compliance.
- Route policy model opinion se decide karna without deterministic checks.
- Logging prompt+personal data indiscriminately.

## Exercise
Ek company ke 3 workload: support FAQ, detailed contracts, sensitive customer data. Design 3 routing rules, one "never route" rule, aur gateway HA requirement.

### Sample reasoning
FAQ: low-cost approved model if task eval threshold met. Contracts: long-document/context-aware model plus human review where needed. Sensitive: allowlist of region/compliant providers; unknown provider = block. HA: redundant gateway nodes with central policy+limits state; load shedding; monitored failure recovery.

**Next:** Cascades aur fallbacks kab cheaper hote hain aur kab dangerous?
