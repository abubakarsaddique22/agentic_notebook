# Class 01 — Requirements se AI System Design start karna
**Module:** M9.1 · **Session:** 1/16 · **Reference:** Chip Huyen, *AI Engineering*, Ch 1, Ch 4, Ch 10

## Learning outcome
Aap product ki vague demand ko **functional requirements, measurable non-functional constraints, traffic estimates, risk rules, aur initial architecture assumptions** mein convert kar sakte hain.

## 1) System design ka asal sawal
Agar stakeholder bole: *"Hamein smart chatbot chahiye"*, ye engineering requirement nahi. AI system designer pehle poochta hai: **Kis user ke liye? Konsa task? Kaunsa data? Success ka proof? Kitni delay acceptable? Failure par consequence kya?**

- **Functional requirement (FR):** System kya karega? Example: company policy ka jawab sources ke saath de; order status real-time tool se dekhe; uncertain case mein human handoff kare.
- **Non-functional requirement (NFR):** Kitna acha/fast/secure/reliable karega? Example: p95 user-visible response latency, incident recovery, tenant-data isolation, spend limit.
- **Constraint:** Jo change nahi kar sakte. Example: user data third-party provider ko send nahi karna; EU tenant data EU mein store; only approved providers.
- **Assumption:** Jab data nahi milta to explicitly likhte hain, baad mein validate karte hain; assumption ko fact nahi banate.
- **Success criteria:** Customer ko actual value mil rahi? Deflection alone enough nahi; wrong resolutions support cost badha sakte hain.

## 2) Requirement discovery: 8 sawal
1. **Users:** End customer, support agent, admin, internal teams kaun hain?
2. **Jobs to be done:** FAQ, billing explanation, order lookup, refund request mein farq?
3. **Data:** Public docs, private account data, internal policies, live transactions?
4. **Accuracy:** Wrong answer ka damage? Finance/medical/legal jaisi high-risk domain mein stricter controls.
5. **Interaction:** 1-turn answer ya multi-step action? Human handoff required?
6. **Scale:** Daily queries, peak QPS, tenants, concurrency, document updates?
7. **User experience:** User ko first token kitni jaldi chahiye? citations? language accessibility?
8. **Governance:** Consent, data retention, audit logs, deletion, provider restrictions?

## 3) Quality ko measurable banayein
Agar "90% accurate" bolna hai, to define karein: **kis dataset, kis rubric, kis evaluator, kis error severity** par? Alag metrics:

| Dimension | Practical measurement | Misleading shortcut |
|---|---|---|
| Answer correctness | Human-labeled task rubric / grounded facts | Sirf answer fluent lagta hai |
| Groundedness | Claim ka cited text se support | Citation diya to automatically correct |
| Tool correctness | Authorized call sahi params par hua | Model ne tool use kiya, bas |
| Resolution | User ka kaam genuinely complete hua | Chatbot ne conversation end ki |
| Safety/privacy | Cross-tenant exposure rate; critical incidents | Prompt mein "be safe" likh diya |
| Cost/latency | p50/p95, per-successful-task cost | Sirf model-token price |

**Leading vs lagging:** Offline eval early warning de sakta hai; actual production resolution aur user trust end outcome hain. Ground-truth unavailable ho to manual review plan karo.

## 4) Traffic estimate aur capacity reasoning (illustrative)
**Assume:** 120,000 user questions/day; traffic peak factor 6× average. Average QPS = 120000 / 86400 ≈ **1.39 req/s**; peak planning point ≈ **8.33 req/s**. Ye planning assumption hai, real traffic distribution nahi.

Agar average end-to-end processing 4 sec hai to Little's Law ke rough approximation se peak in-flight requests ≈ 8.33 × 4 = **33.3**. Iska matlab server sizing automatically 34 nahi; model API concurrency, queue time, p95 latency, bursts, retries, streaming and rate limits alag consider karo.

**Token budget example:** per request 2,000 input + 300 output tokens; 120k daily requests → 240M input + 36M output tokens per day (cache benefits/failures ignore). Is se token pricing aur rate-limit estimate niklega; quality ka proof nahi.

## 5) User journey aur trust boundaries
```mermaid
flowchart LR
 A[User] --> B[Frontend + identity]
 B --> C[API service]
 C --> D{Intent + access check}
 D -->|Knowledge| E[Scoped retrieval]
 D -->|Live status| F[Authorized business API]
 E --> G[LLM generation]
 F --> G
 G --> H[Answer validation]
 H --> I[User or human handoff]
 C --> J[Metrics and audit]
```
**Identity check** ideally business API aur retrieval dono par apply hota hai; sirf model ko "user authorized hai" bol dena authorization nahi. UI aur backend auth boundaries ko separate rakho.

## 6) Scope aur non-goals define karo
MVP ke liye choose kar sakte hain: policy Q&A + cited answer + human escalation. **Non-goals:** autonomous refund, order cancellation, admin data changes. Scope control reliability aur learning dono mein help karta hai.

## 7) Architecture decisions ka evidence format
Decision record (ADR): **Context** (problem), **Options** (A/B/C), **Chosen** (option), **Reason** (quality/latency/cost/risk), **Revisit when** (metric or new condition). Example: "MVP mein write tools nahi; kyun ke error irreversibility high hai; tab reconsider jab audited approval flow ready ho." 

## Common mistakes
- Starting from "LangGraph chahiye" instead of requirement; architecture tool-led ho jati hai.
- Only average latency dekhna; p95/p99 aur cold start ignore.
- Tenant separation sirf prompt mein likhna.
- Cost ko per-query nominal estimate samajh kar retries, tools, indexing, human review ignore karna.

## Practice exercise
**Scenario:** HR assistant employee leave balance bataye, policy PDF se rule explain kare, kabhi leave approve na kare. Aap 3 FR, 4 NFR, 2 risks, 1 non-goal aur 3 success metrics likhein. Kisi ek NFR ko measurable banayein.

### Sample answer / self-check
FR: authenticated balance lookup; cited policy explanation; human escalation. NFR: role-based access; private data redacted from logs; agreed p95 latency; uptime/error monitoring. Risks: cross-employee information leak, stale policy. Non-goal: leave approval. Metrics: verified balance accuracy, answer groundedness, escalation appropriateness. Targets stakeholders ke saath evidence par agree hon—arbitrary promises na karo.

**Next:** Class 02 mein decide karenge baseline prompting se kab RAG, agent ya fine-tuning tak jaana hai.
