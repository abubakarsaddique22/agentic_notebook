# Class 08 — Parallelism, batching, throughput aur inference economics
**Module:** M9.4 · **Session:** 8/16 · **Book:** *AI Engineering* Ch 9, Ch 10

## Goal
Aap parallel vs sequential tasks, model size, context reduction, batching, queueing aur inference deployment decisions ko end-to-end quality+latency+cost lens se evaluate karenge.

## 1) DAG aur critical path
Agar independent calls same input par based hain to simultaneously run ho sakte hain. Dependent work (retrieval results ke bina rerank) parallel nahi ho sakta.

```mermaid
flowchart TD
 A[User query] --> B[Authorize]
 B --> C[Retrieve policy]
 B --> D[Fetch permitted live data]
 C --> E[Context assemble]
 D --> E
 E --> F[Generate answer]
 F --> G[Validate and return]
```

**Illustrative:** policy retrieval 600ms, live API 800ms: sequential = 1,400ms; parallel critical path ≈ 800ms plus coordination overhead. 600ms saved *if* both independent aur service capacity permits. Massive fan-out cost/rate-limit increase kar sakta hai.

## 2) Request concurrency vs batching
- **Concurrent requests:** multiple user tasks in flight; API rate limits, network and memory affect.
- **Batching:** GPU inference on requests/tokens grouped to raise utilization; throughput better ho sakta hai but individual request queue time badh sakta hai.
- **Continuous batching:** Serving engine dynamically active sequences schedule karta hai; self-hosted deployments mein useful.
- **Backpressure:** Overload par queue limit/reject/degrade; uncontrolled queue latency and memory exhaust kar sakti hai.

## 3) Inference architecture choices
| Choice | Pros | Trade-off |
|---|---|---|
| Hosted model API | Infrastructure management kam, easy bootstrap | Per-token spend, provider capacity/privacy constraints |
| Self-hosted small model | Data/control options, predictable high-volume optimization possible | GPU ops, serving expertise, quality evaluation |
| Quantization | Smaller memory footprint, possibly throughput gains | Accuracy/performance variations; test needed |
| Distillation | Smaller model for narrow task | Training-data/eval investment, behavior drift |
| KV/prefix cache | Repeated prompt computation can reduce | Cache residency, provider semantics, privacy considerations |
| Speculative decoding | Can improve decoding under right configuration | Complexity and workload-specific gains |

Chapter 9 in source book these inference optimization themes discuss karta hai. Real hardware sizes and vendor prices time-sensitive hotay hain; design concept ko static benchmark mat samjho.

## 4) Cost formula and sensitivity
Cost per accepted request ≈ (input tokens × current input rate) + (output tokens × output rate) + retrieval + tool fees + validation + amortized fixed cost + retry overhead. **Per accepted request** use karo because rejected/retried attempts cost consume karte hain.

**Example:** 2,000 input tokens and 500 output tokens/request; suppose rates $1 per million input and $4 per million output. Model cost = (2,000 × $1 + 500 × $4) / 1,000,000 = **$0.004** (hypothetical tariffs). Agar model failure 10% attempts ko retry karwaya, simple per-request price underestimate karega.

## 5) Request-per-second planning
Peak 25 QPS with mean service time 4s → roughly 100 concurrent in-flight tasks by Little's Law under stable load; that's system-wide in-flight, not GPUs required. Token bursts, streaming, TPM limit and queue depths separately model karo. Measure *goodput*: successful, within-SLO requests, not raw processed count.

## 6) When to use smaller model
Simple deterministic classification, summarization under strong retrieval evidence, schema validation or extraction; **only after task-based evaluation**. Strong model may be cheaper overall if small model repeatedly retries/escalates.

## 7) Optimization order
1. Remove unnecessary call steps.
2. Fix retrieval and context bloat without quality loss.
3. Parallelize independent I/O.
4. Stream when user UX benefits.
5. Route to measured smaller models.
6. Batch/self-host/quantize if actual volume economics support.

## Practice
Research workflow mein 5 independent pages fetch (400ms each) and one LLM synthesis (1s). Calculate theoretical sequential versus parallel fetching (ignore overhead) and note one real downside.

### Solution
Sequential = 5×400ms + 1,000ms = 3,000ms; parallel fetch all = 400ms + 1,000ms = 1,400ms. Downsides: website rate limits, burst load, network concurrency limits, failure coordination. Ordered/chained search tasks can't all parallelize.

**Next:** Four cache types aur invalidation policies.
