# Class 09 — Caching architecture (exact, prompt, retrieval, semantic)
**Module:** M9.5 · **Session:** 9/16 · **Book:** *AI Engineering* Ch 10; inference caching in Ch 9

## Goal
Aap cache ko "simple Redis lagao" se aage samjhein: **what to cache, key scope, TTL, invalidation, hit rate, freshness, cost and security**.

## 1) Cache kya save karti hai?
Cache repeated work avoid kar sakti hai, **lekin stale truth ko faster serve karna improvement nahi**. AI answers often user, document version, tenant permissions, date aur tool state par depend karte hain.

| Cache type | Store kya hota | Good use | Unique hazard |
|---|---|---|---|
| Exact-response | Same normalized query/request ka final answer | Static public FAQ | Auth/version change |
| Prompt/context (provider/KV/prefix) | Reusable input-token computation/prefix | Repeated stable system prompt | Provider behavior, privacy, prefix mismatch |
| Retrieval | Query → candidate doc IDs/snippets | Mostly stable search corpus | ACL / index change, stale evidence |
| Semantic-response | Similar queries share earlier answer | Carefully bounded generic FAQs | Similar phrasing != same intent, dangerous wrong reuse |

*Note:* Prompt caching aksar provider/inference server feature hota hai, application-level response-cache se different. User billing discounts vendor-dependent hain.

## 2) Cache key and security
Safe key example conceptually: **tenant + role/authorization scope + normalized intent/query + locale + source-version + prompt-version + model-version**. Personal status queries ko shared cache mein kabhi casually key by natural language only mat karo. User ID may need include if data personalized; cache access protect at both read and write.

```mermaid
flowchart TD
 A[Authenticated query] --> B[Eligibility + version policy]
 B --> C{Allowed cache key exists?}
 C -->|Hit| D[Revalidate scope/freshness]
 D -->|Valid| E[Return cached result]
 D -->|Invalid| F[Fetch sources + generate]
 C -->|Miss| F
 F --> G[Validate answer]
 G --> H{Safe to cache?}
 H -->|Yes| I[Write scoped cache + TTL]
 H -->|No| J[Return only]
 I --> J
```

## 3) TTL vs event-based invalidation
**TTL:** Time-based expiry; easy but updates during TTL stale rahengi. **Versioned key:** doc index version badalne se old key unreachable. **Event invalidation:** document/policy change par relevant keys remove. **Hybrid:** event invalidation plus TTL safety-net. Financial prices, order status, approval decisions generally live source check require.

**Caching policy by data class:** Public evergreen help center — good candidate; tenant-specific policy — scoped+versioned; user account balance — generally do not cache as final LLM response; high-risk actions — never reuse prior approval as current approval.

## 4) Semantic cache decision test
Do queries "How to reset password?" aur "I forgot login password" same intent hain? Often yes **if same policy/version**. "Can I return a purchase?" vs "Can I return a purchased digital license?" semantically related lekin different legal exceptions. Similarity threshold alone business-equivalence proof nahi. Use domain allowlist, metadata constraint, quality validation, and miss fallback.

## 5) Hit-rate math (teaching example)
100k eligible requests/day; cache hit rate 35%; each avoided model call costs $0.012. Gross inference avoidance = 100,000 × 0.35 × 0.012 = **$420/day**. But cache storage, invalidation, data leakage risk, hit validation, and any outdated wrong answers not included. Report hit rate **by class and eligible population**, not just global.

## 6) Cache stampede / overload
Popular item expires; 1000 requests simultaneously recompute. Mitigations: single-flight deduplication, jittered expiry, bounded stale-while-revalidate only when safe, prewarming approved public items. For personal/security-critical answers never unconditionally serve stale data.

## 7) Cache metrics
Hit/miss ratio; cache-read latency; stale response incident rate; invalidation propagation time; cost avoided net of caching; accuracy on cache hits vs misses; tenant-scope security tests.

## Interview prompt
"Policy updated 2 min pehle, lekin user ko old refund rule dikh raha hai." Root cause identify: indexing lag, retrieval cache, semantic-answer cache, prompt-prefix stale, copied old session context, version mismatches. Fix needs trace with **source version**.

## Exercise
Customer support has: "password reset steps", "current stock", "user invoice", "general company history". Assign cache category/TTL strategy and defend two refusals.

### Sample solution
Reset + company history: version-aware exact/semantic cache with safeguards; stock: short/no cache depending consistency requirements, live API; invoice: per-user authorized source, usually no shared response caching; refuse cross-user caching and stale confirmation. TTL values company update SLA based determine.

**Next:** Reliability and graceful degradation.
