# Class 02 — Baseline, architecture choice aur trade-offs
**Module:** M9.1 · **Session:** 2/16 · **Reference:** *AI Engineering* Ch 1, Ch 5, Ch 6, Ch 7, Ch 10

## Goal
Aap prompting, RAG, tools, agents aur fine-tuning ke beech justified decision kar sakein; **quality ↔ latency ↔ cost ↔ complexity ↔ reliability** ko ek saath compare karein.

## 1) Baseline before sophistication
Baseline ka matlab simple working reference architecture: **user input → validated prompt → one model → checked output**. Is se eval score, p95 delay aur cost ka "before" number milta hai. Agar ye enough hai, to agent banana complexity waste hai. Jab error analysis dikhaye ke external facts missing hain tab retrieval add karo; jab real-world action required ho tab authorized tools consider karo.

```mermaid
flowchart TD
 A[Product requirement] --> B[Evaluation dataset + constraints]
 B --> C[Prompt-only baseline]
 C --> D{Target met?}
 D -->|Yes| E[Ship with monitoring]
 D -->|No| F{Failure reason?}
 F -->|Missing source facts| G[RAG or external lookup]
 F -->|Needs action| H[Deterministic tool workflow]
 F -->|Complex open planning| I[Bounded agent]
 F -->|Style or repeated skill gap| J[Consider fine-tuning]
 G --> K[Re-evaluate end-to-end]
 H --> K
 I --> K
 J --> K
```

## 2) Options ka comparison
| Option | Kab choose | Strength | Risk/expense |
|---|---|---|---|
| Prompting | Model pehle se task kar sakta; static instructions | Fastest MVP | New/private facts absent |
| RAG | Private ya frequently changing documents se grounded answer | Update facts without retraining | Retrieval quality/ACL/index staleness |
| Direct tools | Live records ya exact calculations/action | Up-to-date + deterministic boundary | Tool errors/auth complexity |
| Workflow | Fixed steps and approvals | Predictable, testable | Dynamic plans limited |
| Agent | Tool selection/replanning truly uncertain | Flexible complex tasks | Loops, non-determinism, token cost, risk |
| Fine-tuning | Stable repetitive output/behavior gap with quality data | Can improve model behavior | Data+training+evaluation, not live facts |

**Important:** Fine-tuning ko aaj ke order status ka replacement mat samjho. Live data APIs se aata hai. RAG bhi har jagah answer nahi—money calculations deterministic backend par karo.

## 3) Trade-off mechanics
**Quality:** factual correctness, policy adherence, useful output, citation accuracy. **Latency:** user-perceived wait + total completion. **Cost:** inference, retrieval storage, GPUs/compute, annotation, monitoring, human operations. **Reliability:** dependency failures, malformed output, security, rollback. **Complexity:** new components = new failure paths and testing work.

### Example (purely illustrative)
| Candidate | Grounded-answer quality on held-out eval | p95 latency | Cost/request | Decision |
|---|---:|---:|---:|---|
| A Prompt-only | 68% | 1.8 s | $0.003 | Insufficient quality |
| B RAG + one model | 91% | 3.4 s | $0.010 | Candidate |
| C Multi-agent | 92% | 11 s | $0.058 | Extra 1 point not worth it for FAQ |

Numbers **hypothetical teaching dataset** hain, vendor benchmark nahi. Agar target grounded quality ≥90% and p95 ≤5 sec hai, to B reasonable. Production decision before rollout human-labeled error analysis se validate karo.

## 4) Architectural sufficiency test
Har proposed component ke liye ye question poochho:
1. Kaunsa measured failure ye solve karega?
2. Kya smaller/deterministic approach possible hai?
3. Naya risk kya introduce hota hai?
4. Kya rollback aur isolated test possible hai?
5. Kya woh original requirements aur budget mein fit hai?

**Pareto frontier:** Agar A ki quality better **aur** cost/latency lower ho compared to B, to B dominated hai. Trade-off ka matlab kabhi sirf ek number maximize karna nahi—hard requirements pehle filter, baqi options among feasible.

## 5) Baseline evolution example
- v0: static FAQ with curated snippets; no LLM write actions.
- v1: Prompted model over selected FAQ; offline evaluation.
- v2: RAG for larger frequently changing policies; include citations.
- v3: Authorized tool for account status; model does not invent account details.
- v4: Approved write workflow only after fraud/risk + human signoff.

Yeh mandatory sequence nahi: use-case ke mutabiq v0 hi final ho sakta hai.

## 6) Design interview mein kaise jawab dein
Problem: "10,000 policy PDFs par chatbot design karo." Pehle 5 questions: tenants? update frequency? role-based permissions? source citations required? latency/QPS? Phir baseline document search + model, retrieval eval, security, cache freshness, fallback aur monitoring. Tool/vendor names **aakhri step** mein.

## Common failure modes
- Agent use karna sirf isliye ke "agentic AI" trend hai.
- RAG add karna bina retrieval recall measure kiye.
- Fine-tune data shortage ignore karna.
- High benchmark model choose karna bina own task evaluation.
- Quality increase ko production reliability increase samajhna.

## Practice
Company ki flight policy (monthly updates), seat inventory (live), travel expense approval (write, high risk), marketing taglines (style) — har task ke liye prompting/RAG/tool/approval/fine-tune ka design aur 1 rejected alternative likho.

### Suggested rationale
Policy: RAG with source/version; inventory: authenticated live API; approval: deterministic business rules + human authorization, optional model to draft explanation; tagline: prompt baseline, fine-tune only if stable domain style gap and data justify. Agent tab jab genuinely open multi-step itinerary research required ho.

**Next:** Knowledge actually kahan rehti hai aur kis source par trust karna chahiye?
