# Class 07 — Latency breakdown, TTFT, streaming aur SLO
**Module:** M9.4 · **Session:** 7/16 · **Book:** *AI Engineering* Ch 9 (inference), Ch 10 (architecture)

## Outcome
Aap slow AI request ka **critical path** identify kar sakte hain aur user-perceived latency versus total execution latency ka difference measure kar sakte hain.

## 1) Latency vocabulary
- **End-to-end latency:** User request to completed final result.
- **TTFT (Time to First Token):** Model request start se pehle output token tak wait. Total UI initial response mein network and retrieval bhi shamil ho sakte hain; clearly define boundary.
- **TPOT (Time per Output Token):** Generation token speed ka measure; different implementations differ—formula/documentation specify.
- **TBT (Time Between Tokens):** Stream mein tokens ke darmiyan delay.
- **Throughput:** Tokens/sec, requests/sec under concurrency.
- **p50/p95/p99:** Distribution quantiles; average-only reporting slow tail conceal karta hai.

## 2) Latency waterfall
```mermaid
flowchart LR
 A[Network+auth] --> B[Query/intent]
 B --> C[Retrieval]
 C --> D[Rerank+pack]
 D --> E[Model TTFT]
 E --> F[Token generation]
 F --> G[Validation+return]
```

**Illustrative single request:** auth/network 100 ms + routing 70 + retrieve 220 + rerank 180 + model TTFT 650 + generation 1,300 + validation 80 = **2,600 ms** sequential critical path. Lekin p95 components ka sum **necessarily** full-system p95 nahi hota; timings correlated ho sakti hain, traces se end-to-end distribution dekho.

## 3) Streaming perceived latency change karti hai
Model token-by-token deliver kare to user early reading start kar sakta hai. **TTFT improve perceived speed**, lekin total compute/token bill necessarily reduce nahi. Streamed answer baad mein contradictory ho sakta hai; UI ko unfinished text as final decision na treat karna chahiye. Financial write approval jaisi actions par "partial success" dikhana dangerous hai.

**Design:** Progressive status ("Searching approved documents"), source citations final verify, cancel handling, deadlines, backpressure. User ka trust slow-but-correct handoff se kabhi better hota hai compared to fast fake answer.

## 4) Latency budget allocation
Requirements se reverse plan: "p95 full answer ≤5 sec under peak workload" (illustrative). Budget line items: admission/network 0.4; retrieval 0.8; rerank 0.4; model first token 0.8; generation 2.2; validation 0.4 = 5.0 sec *design allowance*. Actual distribution test karo and headroom rakho. Per-stage budgets are planning tools, guarantee nahi.

## 5) Diagnostic method
**Step 1:** Trace spans all boundaries. **Step 2:** Slow p95 requests ka breakdown. **Step 3:** Bottleneck find (model first token? context size? serial tool calls? data store?). **Step 4:** One change at a time and evaluate quality/cost. **Step 5:** At peak traffic p95/p99 and failure rate check.

**Long output** decode cost barhata hai. **Long input** prefill delay and cost barha sakta hai. Useful context trim karein, not blindly delete key policy text.

## 6) When model size is not the bottleneck
Poorly indexed retrieval 2 seconds consume karta ho to strong-to-small model switch se little difference. DNS/network overhead or rate-limited provider may cause queues. Amdahl's law intuition: non-model slow part unchanged rahe to overall gains limited.

## 7) Product SLO design
Define **success criteria**: percentage of successful authorized user tasks under latency limit, time window, tenant/region, excluded cases clearly. Availability without accurate answers is partial health. Separate first-response and completion SLO where streaming.

## Common mistakes
- Model p95 ko total user p95 samajhna.
- Artificial constant sleep/test latency as "production benchmark".
- Caching se faster responses measure but stale harmful answers ignore.
- Every call serial even when independent.

## Exercise
Trace: auth 100ms, docs retrieve 1.8s, rerank 100ms, model 900ms. User complains 3s. Pehle kya optimize karoge aur success kaise validate?

### Worked response
Retrieval dominates: index/filter and source store timing inspect, caching valid safe keys, query design improve. Compare recall before/after, not only latency. Total trace baseline ≈ 2.9 sec plus omitted processing; real p95 test needed.

**Next:** Parallelism, batching, scaling aur actual inference optimization.
