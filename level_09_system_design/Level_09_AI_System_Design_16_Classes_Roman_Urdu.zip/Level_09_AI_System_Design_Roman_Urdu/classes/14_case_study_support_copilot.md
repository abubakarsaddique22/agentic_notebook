# Class 14 — Case study 1: Production Customer-Support Copilot
**Module:** M9.9 · **Session:** 14/16 · **Book:** *AI Engineering* Ch 6, Ch 10 (architecture)

## Goal
Interview-level design: requirements → baseline → architecture → bottlenecks → failures → scaling → trade-offs. **Everything here fictional and illustrative.**

## 1) Interview question
"Design an AI support copilot serving multiple companies. It must answer policy FAQs from latest documents, cite sources, show authenticated order status, offer human escalation, and stay within a tight latency/cost budget."

### Requirement discovery
- **Users:** customer and support staff; tenant isolation mandatory.
- **Read tasks:** policy/FAQ (versioned docs), order status (live CRM/order API).
- **Write tasks:** refunds or changes not in initial MVP; later approval-gated.
- **UX:** source links for policy, direct status for account queries, abstain when unsure.
- **Assume for design:** 30,000 questions/day, peak 10 QPS, p95 complete response ≤6 sec, 99.5% eligible read requests successful in the measurement window. **These are hypothetical targets, not guaranteed outcomes.**
- **Privacy:** tenant-restricted knowledge and identity-verified account data.

## 2) Baseline
One approved model + single-curated FAQ per tenant + measured test set. Analyze: old policy? wrong customer status? long latency? Enhance only validated gaps. Independent exact lookup for order data instead of free-text RAG.

## 3) Proposed architecture
```mermaid
flowchart TB
 U[Customer] --> F[Web/Chat UI]
 F --> A[API: auth + tenant context]
 A --> P[Intent and policy router]
 P -->|FAQ| R[Hybrid retrieval with ACL]
 P -->|Order status| O[Authorized order API]
 R --> K[Versioned evidence + citations]
 O --> K
 K --> G[Model gateway and route]
 G --> L[LLM answer]
 L --> V[Schema/citation/PII checks]
 V -->|Passed| F
 V -->|Insufficient| H[Human escalation]
 F --> H
 A --> M[Safe traces and metrics]
 R --> I[(Tenant-scoped indexed docs)]
```

**Component justification:** Auth before retrieval protects tenant data; lexical+vector supports exact policy IDs and paraphrases; citations map to actual source IDs; order status calls backend; gateway allows validated cheaper routing, fallback pretested; human escalation handles inability to verify.

## 4) Context/data design
- **Ingest:** authoritative KB via connectors; version/time/ACL metadata; job audit and dead-letter.
- **Retrieve:** filter tenant+role first; hybrid search; rerank; pack effective policy passages.
- **Live status:** user identity + record ownership → order API; response timeouts.
- **Answer:** identify source type, cite policy sections, don't fabricate unavailable order state.
- **Update:** publish new index version, invalidate exact/retrieval/semantic caches as needed.

## 5) Model and routing
FAQ + strong evidence: smaller validated model; ambiguous multi-document synthesis: strong approved model; expensive route gated by budget. In high-risk or low evidence case abstain/handoff. API provider change must pass golden eval; privacy region a hard filter.

## 6) Cache choices
**Public/general FAQ:** exact or restricted semantic cache with version. **Tenant policy:** tenant, ACL scope, effective version in key; short TTL + event invalidation. **Private order status:** don't share result cache; direct API recommended. Prompt-prefix cache only when service privacy rules satisfied.

## 7) Failure matrix
| Failure | Detection | User-safe behavior |
|---|---|---|
| Order API down | Timeout/5xx | No made-up status; support handoff |
| Retrieval no match | Low evidence | Ask clarifying question or handoff |
| Policy index stale | Version lag alert | Use current approved source or abstain |
| Model provider down | Gateway error | Approved fallback; otherwise honest unavailability |
| High load | p95 queue/timeouts | Backpressure, bounded queue, alternative support |
| Cross-tenant access | ACL negative test/incident | Block; alert security |

## 8) Capacity and budget (illustrative)
30k requests/day = 0.347 average QPS, peak provision 10 QPS (traffic peaks large). If average 2,500 input + 350 output tokens per completion and 30k model calls/day, nominal 75M input + 10.5M output tokens daily. Routing, cache hits, retries, and partial tool-only tasks change numbers. Use rate forecasts plus measured actual.

**Latency budget idea:** auth 0.3s, query/routing 0.2s, retrieval+rerank 0.9s, model TTFT 1.0s, generation 3.0s, validation/return 0.6s = **6.0s sequential planning allowance**. Actual p95 cannot be promised by adding stage budgets; load-test entire request path.

## 9) Observability and rollout
Measure citation support, wrong-order incident rate, escalation precision, verified resolution, p95 latency, cost per resolved task, per-route answer quality. Run canary with support agents reviewing sample replies; include cross-tenant adversarial tests and index deletion checks before production.

## 10) Explicitly rejected alternatives
- **Fine-tune instead of RAG:** cannot guarantee up-to-date tenant policy and provenance.
- **RAG for live order state:** creates stale personal data and authorization complexity.
- **Autonomous multi-agent default:** unnecessary for majority of single-intent FAQs; higher cost/complexity.
- **Shared semantic answer cache:** unacceptable cross-tenant leakage risk.

## Interview script: 90-second defense
"I begin with requirement and risk classification. I split knowledge answers and authoritative live lookups, isolate by authenticated tenant context, keep a simple baseline, introduce RAG only for versioned content, use tested model routing, never allow the model to authorize writes, measure end-to-end quality/latency/cost and provide explicit human fallback. I can justify each component by a specific requirement or observed failure."

## Practice
Interview variation: policies update 10 times/day, 10x peak traffic, and refund requests now allowed. Give **3 architecture changes** and **one trade-off** per change.

### Sample responses
Event-driven reindex/version invalidation (freshness vs processing cost); queue/backpressure + scale gateway/retrieval (availability vs queue delay); refund workflow with server-side policy, human confirmation, idempotent writes (safety vs throughput/UX). Validate metrics under changed load, not guess.

**Next:** Coding assistant aur deep research agent do contrasting architectures.
