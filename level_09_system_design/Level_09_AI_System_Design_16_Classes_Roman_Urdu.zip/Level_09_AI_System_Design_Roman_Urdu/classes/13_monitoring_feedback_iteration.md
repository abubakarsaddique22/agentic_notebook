# Class 13 — Observability, evaluation, feedback, versioning
**Module:** M9.8 · **Session:** 13/16 · **Book:** *AI Engineering* Ch 4, Ch 10

## Goal
Aap AI system ko **deploy → observe → evaluate → improve → redeploy** loop mein le ja sakte hain, jahan quality regressions traceable hon aur logs private data expose na karein.

## 1) Monitoring ≠ observability
**Monitoring:** Known metrics/alarms: 5xx rate high? p95 slow? **Observability:** Unknown failure ka root cause diagnose: user request → retrieval source IDs → route/model version → tool call → final validation. Structured logs, traces and metrics ek doosre ko complement karte hain.

```mermaid
flowchart LR
 A[Prod requests] --> B[Traces, logs, metrics]
 A --> C[Explicit + implicit feedback]
 B --> D[Failure mining]
 C --> D
 D --> E[Labeled eval dataset]
 E --> F[Change + offline eval]
 F --> G[Canary / rollout]
 G --> A
```

## 2) Three signal families
**Operational:** Request rate, error rate, p50/p95/p99, timeouts, queue depth, token usage, cost, provider rate limits. **AI-specific:** faithfulness/grounding, retrieval recall@k, citation validity, hallucination severity, tool correctness, refusal quality, answer completeness. **Product:** support resolution, human handoff, repeat contacts, time saved, satisfaction.

**No single success metric** captures everything. Positive thumbs-up but unsupported financial answer can still be harmful.

## 3) Trace anatomy
`trace_id` links high-level request to spans: identity validation, knowledge retrieval, reranking, model gateway route, model, tools, output checks. Each span records **duration**, status, configuration/version IDs and safe metadata. Raw personal prompts, credit card IDs, secrets and private documents must not be indiscriminately persisted. Need-to-know retention and redaction.

## 4) Golden eval dataset
Representative tasks with expected evidence + scoring rubric + severity: (a) easy FAQ, (b) version-conflicting policy, (c) ambiguous question, (d) cross-tenant attempted access, (e) tool timeout, (f) multilingual prompt. Include **hard negative cases**. Freeze eval sets for regressions, add incident-derived examples, and maintain held-out set against overfitting.

### Evaluation stages
1. Unit/schema tests for deterministic tools.
2. Retrieval tests on labeled queries/documents.
3. Response tests for accuracy and groundedness.
4. Security adversarial tests and privilege checks.
5. Load/chaos tests and cost under realistic traffic.
6. Canary and user feedback analysis.

AI-as-a-judge can help scale some checks but can be biased/inconsistent; calibrate against human-graded samples and never replace critical access-control tests.

## 5) Feedback: explicit vs implicit
**Explicit:** thumbs up/down, error report, corrected response, staff judgment. **Implicit:** copied answer, user asks again, escalates, cancels workflow, abandons task. Implicit signals ambiguous: user abandoning can mean resolved or frustrated. Use careful interpretation, not one-click "reward" training.

**Sampling:** low-volume high-risk cases audit more; stratify by tenant, task type, language, model version. Feedback selection bias documented.

## 6) Version control as architecture
Record prompt template version, model/provider, retriever/index version, embedding model, reranker, schema/policy version and feature flags. Example: after deploy, groundedness falls for a certain tenant. Diff traces to see whether doc index, reranker or system prompt changed. Without versions, blame model blindly.

## 7) Drift and incident response
Detect changing user traffic, changed docs, unsupported claims, provider output changes, increased refusal rate. **Response:** alert owner, disable risky feature/fallback route, rollback if needed, investigate with privacy-safe traces, add regression test, write postmortem. Retraining is only one possible correction; often retrieval/config fixes enough.

## 8) Dashboard design (minimal)
| Panel | Metric | Example action if bad |
|---|---|---|
| Reliability | valid completion %, 5xx, rate limits | Rollback or alternate path |
| UX | p95 TTFT and total latency | Inspect slow spans |
| Quality | task-specific human rubric, groundedness | Regression analysis |
| Retrieval | recall@k, stale-source count | Re-index/filter tuning |
| Safety | authorization blocks, incidents | Security investigation |
| Cost | spend per successful task, route distribution | Routing/caching review |
| Product | task resolution and repeat contacts | UX/workflow review |

## Practice
New prompt shipped, response looks smoother but support users complain about wrong refund policy. How investigate?

### Suggested answer
Compare prompt and retrieval index versions; segment affected tenants/cases; inspect citation/source freshness and failed traces; replay curated test set; rollback if material harm; add complaint cases to eval; monitor before redeploy. Fluency quality ka sufficient signal nahi.

**Next:** End-to-end customer support copilot case study.
