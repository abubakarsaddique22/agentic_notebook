# Class 06 — Model cascades, quality checks, fallback aur risk
**Module:** M9.3 · **Session:** 6/16 · **Book:** *AI Engineering* Ch 4, Ch 10

## Goal
Aap simple request ko cheap model aur tough request ko capable model tak route karne ki strategy bana sakte hain—**quality, uncertainty, fallback aur cost** ka evidence ke saath.

## 1) Model cascade kya hai?
Cascade = staged routing: pehle low-cost capable model; agar confidently satisfactory nahi to next model or human. **Escalation** ke liye reliable signal chahiye (well-defined validator, domain rubric, calibrated classifier). "Model bol raha hai 99% confident hoon" dependable quality guarantee nahi.

```mermaid
flowchart TD
 Q[User request] --> P[Policy / privacy checks]
 P --> S[Simple model]
 S --> V{Valid and quality gates pass?}
 V -->|Yes| A[Return answer]
 V -->|No| H[Stronger approved model]
 H --> G{Verified?}
 G -->|Yes| A
 G -->|No| E[Abstain or human escalation]
```

## 2) Basic expected-cost reasoning
**Illustrative only:** first model $0.002/request, strong model $0.020/request; 25% of requests escalate. Model-only expected cost ≈ $0.002 + 0.25 × $0.020 = **$0.007** per request (excluding validation, retrieval, overhead, failed calls). All requests strong model = $0.020. Saves money **only if** low-tier answers are sufficiently correct and validation cost/risk stays small.

**Critical:** Escalations ki latency worse hoti hai because sequential calls. Agar p95 SLA strict hai, pre-route hard queries directly to strong model instead of waiting for cheap failed attempt.

## 3) Router versus cascade
**Router:** start mein task features dekh kar model choose. **Cascade:** first output inspect karke next step decide. Dono combine ho sakte hain. Routing wrong → inappropriate model; cascade bad validator → silent incorrect answer.

## 4) Fallback != equal quality
Provider down ho to alternate model use karna operational continuity de sakta hai, lekin:
- **Schema:** JSON/tool-call semantics different ho sakti hain.
- **Context:** Alternate ka context length aur modality support different.
- **Safety:** Policy compliance and data residency ensure.
- **Quality:** Alternate model ko own eval set par pehle test.
- **Cost:** Backup significantly expensive; budget cap.
- **State:** Partial streaming response ke beech model switch easily hidden nahi hota; UX specify.

## 5) Failure ladder
1. Safe retry only for transient failure, within request deadline.
2. Healthy provider in same approved capability class.
3. Reduced-function answer: "Live account lookup temporarily unavailable".
4. Human escalation or clear unavailability; fabricate mat karo.

**Example:** Order status API down; other LLM fallback se status guess karna invalid. Correct degradation: case create, official status unavailable inform, follow-up option.

## 6) Confidence and output validation
- Deterministic: schema valid? source citations refer to retrieved IDs? numeric range correct?
- Domain-specific: evidence covers question? tool output consistent?
- Human reviewed scoring/rubric: hallucination frequency, unsupported claims.
- Routing calibration: accepted cheap-model answers ka measured error rate per class.

**Selective prediction**: system difficult cases abstain karta hai. Measure *coverage* (answered %), *risk at coverage*, and escalation cost. Sirf aggregate accuracy misleading ho sakti hai.

## 7) Safe rollout
Holdout dataset compare; shadow routing without exposing results; canary tenants; fallback path chaos testing; cost ceilings; rollback switch; trace route+model version. Human escalation availability queue planning bhi design ka part hai.

## Exercise
A legal-doc assistant 70% requests cheap model pe pass karta hai, lekin unsupported citations zyada produce karta hai. Kya cascade deploy karna chahiye?

### Sample answer
Nahi jab tak measured citation-grounding risk threshold meet na ho. Calibrated validator, citation source linking, per-severity eval, confidence/coverage curve, and human escalation gate improve karo. Potential savings reliability aur risk se kam important hain. Routing must account for data privacy rules.

**Next:** Latency ko actual components mein todna.
