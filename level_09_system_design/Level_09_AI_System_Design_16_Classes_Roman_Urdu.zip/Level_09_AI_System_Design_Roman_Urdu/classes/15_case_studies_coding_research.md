# Class 15 — Case studies 2 & 3: Coding assistant vs Deep research agent
**Module:** M9.9 · **Session:** 15/16 · **Book:** *AI Engineering* Ch 6, Ch 10

## Goal
Do alag AI systems ko architecture-first reason karna: **large codebase retrieval + controlled execution** versus **long-running web research + citations + budgets**. Dono mein baseline aur rejected alternatives explicit.

# Case study A — Coding assistant for large codebase

## 1) Product requirements
User repo ko samajhkar file navigation, code explanation, proposed patch aur optional test run; sensitive code/private secrets protect; wrong edit reversible; IDE latency responsive. Multi-repo tenancy/permissions. **Non-goals MVP:** autonomous production deployment, secret extraction, shell command execution without sandbox.

## 2) Architecture
```mermaid
flowchart TB
 U[Developer IDE] --> A[Authenticated workspace service]
 A --> B[Repo permission scope]
 B --> C[Symbol / text / semantic code search]
 C --> D[Relevant files + dependency graph]
 D --> E[Prompt + model gateway]
 E --> F[Patch proposal]
 F --> G[Static checks + human review]
 G -->|Approved| H[Isolated test runner]
 H --> I[Diff, test evidence, next action]
```

**Why symbol/lexical + semantic?** Code-specific exact names, paths, imports often better served by lexical/symbol index; semantic retrieval helps concept explanations. Search should respect branches and file revisions; index invalidated on commit/change.

## 3) Tool/execution boundary
LLM can propose test command, but actual execution only in isolated workspace sandbox with explicit allowlist, limited filesystem/network, CPU/time/memory, and no production credentials. Output from tests is untrusted content; tool errors and exit codes authoritative; user approves patches. Git diff is a clear review artifact.

## 4) Performance and reliability
Local file search sub-second when possible; complex patch task can stream progress and run asynchronously. Cap number of file reads, context tokens, test retries. Model route based on complexity and supported codebase size; measure test pass, accepted diffs, regression rate, wrong-file edits. **Model output passing syntax != feature correct**; unit tests, integration tests and human review matter.

## 5) Rejected alternatives
- Whole repository always in context: expensive and dilutes relevance.
- Vector-only search: may miss exact symbols/path names.
- Unrestricted shell or internet: privacy and supply chain risk.
- Agent autopush to main: unreviewed irreversible impact.

## 6) Exercise A
"Model suggested editing `auth.py`, but current branch has renamed file." Diagnose: index lag, branch mismatch, stale cached context; retrieve branch-aware metadata and require current diff validation.

# Case study B — Deep research agent

## 1) Product requirements
Open-ended user question par multi-source research, planning, parallel approved searching, source tracking, synthesis with real citations, long-running status, interruption/resume, total time/token/search budget. Claim freshness and search limitations visible.

## 2) Architecture
```mermaid
flowchart TD
 U[Research request] --> P[Scoper and bounded planner]
 P --> Q[Persistent job + budget]
 Q --> S1[Search source A]
 Q --> S2[Search source B]
 Q --> S3[Search source C]
 S1 --> X[Source registry / dedupe]
 S2 --> X
 S3 --> X
 X --> R[Evidence quality & conflict check]
 R --> G[Draft with source-linked claims]
 G --> V[Citation verification]
 V --> O[Report + caveats]
```

**Parallelization:** Independent searches can overlap; results dependent follow-up queries require sequential iteration. Planner is bounded by allowed websites, tool calls, money, elapsed time and stop conditions.

## 3) Evidence management
Store title, canonical URL/reference, retrieval time, publication date if known, author/publisher, excerpts, credibility/relevance and claim mapping. Source citations must reference fetched content; fabricated sources prohibited. Conflicting claims → compare authority, dates, and disclose uncertainty. Copyright and source access rules respected.

## 4) Jobs and failure recovery
Research may exceed synchronous web request timeout: queue job, persist checkpoints, return job ID/status, cancel support, retry individual transient fetch only, de-duplicate repeated URLs. Errors/partial coverage reported. User doesn't receive "complete" until objective/quality checks pass, but can receive clearly marked partial report where product allows.

## 5) Cost and quality trade-offs
Early stopping when coverage sufficient; prioritize authoritative sources rather than unlimited searching; per-source fetch caps and token budget; stronger model for final synthesis when eval shows benefit. Cheap model hallucinating citations increases downstream audit cost.

## 6) Rejected alternatives
- One prompt "write a deep research report" with no sources: no verifiable evidence.
- Unbounded recursive autonomous agent: runaway cost and loops.
- All search calls sequential: avoidable delay where independent.
- Infinite memory of full web pages in context: context bloat; use source registry/retrieval.

## 7) Compare the three cases
| Dimension | Support copilot | Coding assistant | Research agent |
|---|---|---|---|
| Main knowledge | Policies + live account API | Repo/AST/symbols + docs | Web/multi-source evidence |
| Key risk | Wrong account data, stale policy | Unsafe code execution/changes | Unsupported citations, runaway budget |
| Orchestration | Mostly deterministic | Hybrid workflow + sandbox | Bounded long-running agent |
| State | Session + incident/handoff | Workspace/branch/patch state | Durable job + source registry |
| Success | Verified resolution | Tests + accepted patch | Supported, comprehensive report |

## Interview practice
Design a coding assistant for 1M-line monorepo and research agent for 30-minute investigation. Present requirements, baseline, data flow, critical safety boundary, latency and budget controls, failure handling, rejected alternative for **each**.

### Answer hints
Monorepo: branch-aware indexing, symbol search, exact file matching, sandbox test. Research: queued job, planned bounded iterations, evidence registry/citation checks, resumable state. Both need tenant isolation, observability and eval, but long-running execution and risk profile differ.

**Next:** Full capstone design document with worked numbers, assumptions and trade-offs.
