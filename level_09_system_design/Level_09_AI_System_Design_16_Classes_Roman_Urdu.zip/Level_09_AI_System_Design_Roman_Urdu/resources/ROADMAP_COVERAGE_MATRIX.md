# Original Roadmap Level 9 — Topic-by-topic coverage matrix

**Verified source:** https://ai-engineer-roadmap-2026.vercel.app/level/9/ (10 modules, 16 sessions). Ye matrix official topic descriptions ko classes ke saath align karti hai. Class notes Roman Urdu original explanations hain.

| Original module | Roadmap ka specific requirement | Coverage |
|---|---|---|
| M9.1 | Starting from requirements & constraints: use-case, success, traffic, privacy, cost | Class 01 |
| M9.1 | Prompting/RAG/agents/fine-tuning ka deliberate choice | Class 02 |
| M9.1 | Quality ↔ latency ↔ cost ↔ complexity/reliability | Class 01–02 |
| M9.1 | Baseline before sophistication | Class 02 |
| M9.2 | Knowledge: model/context/RAG/memory/tools | Class 03 |
| M9.2 | Full context ingestion→retrieval→rerank→assemble→generate | Class 04 |
| M9.2 | Vector+keyword+graph retrieval when justified | Class 04 |
| M9.2 | Freshness, updates, ACL, scale, provenance | Class 03–04 |
| M9.2 | Dynamic retrieval vs permanently in context/state | Class 03 |
| M9.3 | Model gateway abstraction | Class 05 |
| M9.3 | Route by task, cost, risk, context, modality, latency | Class 05 |
| M9.3 | Model cascades | Class 06 |
| M9.3 | Provider fallbacks and quality risk | Class 06 |
| M9.3 | Central auth, limits, usage tracking, retries | Class 05 |
| M9.4 | Latency breakdown (retrieval, TTFT, generation, tool/network) | Class 07 |
| M9.4 | Streaming for perceived latency | Class 07 |
| M9.4 | Parallelize independent work | Class 08 |
| M9.4 | Small model if task eval supports | Class 08 |
| M9.4 | Context reduction + batching + serving optimizations | Class 08 |
| M9.4 | Throughput, utilization at scale | Class 08 |
| M9.5 | Exact-response/prompt/retrieval/semantic caching | Class 09 |
| M9.5 | Cache eligibility, expiry/invalidation | Class 09 |
| M9.5 | Semantic equivalence vs factual mismatch | Class 09 |
| M9.5 | Freshness/latency/cost trade-off | Class 09 |
| M9.5 | Actual hit rate and savings | Class 09 |
| M9.6 | Model/tool/rate-limit/malformed/retrieval failures | Class 10 |
| M9.6 | Timeouts, retries, circuit breakers, queues | Class 10 |
| M9.6 | Guardrails at important system boundaries | Class 11 |
| M9.6 | Graceful degradation | Class 10 |
| M9.6 | Human approval for high-risk actions | Class 11 |
| M9.6 | Availability, latency, quality service-level expectations | Class 11 (+07/10) |
| M9.7 | End-to-end retrieval/model/tools/guardrails/cache flow | Class 12 |
| M9.7 | Deterministic vs model-delegated decisions | Class 12 |
| M9.7 | Sync/async/queue/long-running | Class 12 |
| M9.7 | Avoid unnecessary agents | Class 12 |
| M9.7 | Independently replaceable/evaluable components | Class 12 |
| M9.8 | Eval + feedback + traces + metrics in production | Class 13 |
| M9.8 | Monitor quality, latency, cost, retrieval, tools, provider | Class 13 |
| M9.8 | Explicit/implicit feedback | Class 13 |
| M9.8 | Production failures → evaluation cases | Class 13 |
| M9.8 | Versioning, deploy/observe/improve/redeploy loop | Class 13 |
| M9.9 | Whiteboard and defend architecture | Classes 14–15 |
| M9.9 | Customer-support copilot: RAG/citations/routing/cache/escalation | Class 14 |
| M9.9 | Coding assistant: codebase/retrieval/execution/sandbox/long jobs | Class 15A |
| M9.9 | Research agent: search/planning/parallelism/context/jobs/citation/budget | Class 15B |
| M9.9 | Requirements→baseline→bottlenecks→failure→scale→trade-offs | Classes 14–15 |
| M9.10 | Complete document: requirements, traffic, diagram, routing, RAG, tools | Class 16 §§1–8 |
| M9.10 | Cache, latency/cost, reliability/fallback, security | Class 16 §§9–12 |
| M9.10 | Evaluation/monitoring/feedback, scaling | Class 16 §§13–15 |
| M9.10 | Rejected alternatives and justification | Class 16 §14 |

## Coverage note
16 classes roadmap ka exact session count follow karti hain; M9.9 ke teen named case studies **do** sessions mein intentionally grouped hain, as official schedule gives 2 sessions. Examples, exercises, and detailed methodology course-created additions hain; official site unko verbatim prescribe nahi karta.
