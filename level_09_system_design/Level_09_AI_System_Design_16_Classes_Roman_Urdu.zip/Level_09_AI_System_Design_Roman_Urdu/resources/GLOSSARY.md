# Level 9 Glossary — Roman Urdu

Is glossary ko har class ke saath reference ki tarah use karo. **Examples and thresholds context-dependent hain.**

## Architecture aur planning
| Term | Roman Urdu meaning | Practical implication |
|---|---|---|
| Architecture | System ke components aur unke relations ka design | Sirf boxes nahi; data, errors, owners aur access rules |
| Functional requirement (FR) | System kya karay ga | "Order status show kare" |
| Non-functional requirement (NFR) | System kitna fast, reliable, safe hona chahiye | "p95 full answer agreed time under peak" |
| Constraint | Aisi limit jisay violate nahi kar sakte | Data residency, approved providers, privacy |
| SLO | Target service behavior | Clear metric + time window |
| SLI | SLO ko measure karne wala signal | Valid answers completed / eligible requests |
| SLA | Customer-facing service agreement | Contractual availability/support expectations |
| ADR | Architecture Decision Record | Chosen vs rejected + rationale + revisit trigger |
| Critical path | Longest dependent execution path | Parallel branches ko simply sum nahi karte |
| Throughput | Per second useful work | Requests/sec or tokens/sec; specify units |
| Goodput | Successfully useful, within-SLO work | Failed requests raw throughput inflate kar sakte |
| Backpressure | Overload par intake control | Bounded queue, load shedding |
| Bulkhead | Failure isolation | Tenant A load tenant B ko drown na kare |

## Models aur evaluation
| Term | Meaning | Practical implication |
|---|---|---|
| Foundation model | Pretrained general-purpose model | Application mein adapt through prompt/context/tools/fine-tune |
| Prompt baseline | Simplest model call solution | Improvements ke liye measurable baseline |
| RAG | Retrieval-augmented generation | External evidence fetched at question time |
| Agent | Model-led bounded decisions/tool selection | Useful only with genuinely uncertain multi-step work |
| Fine-tuning | Targeted further model training | Not equivalent to live database knowledge |
| Model gateway | Stable policy/control layer for providers | Auth, telemetry, budgets, provider abstraction |
| Router | Model/provider selection policy | Based on task, risk, latency, cost, etc. |
| Cascade | Cheap/early stage, escalate on verified failure | Validator must be reliable |
| Groundedness | Answer supported by supplied sources | Source citations must be checked |
| Hallucination | Unsupported/invented assertion | Detect severity, reduce through evidence and abstention |
| Evaluation dataset | Labeled representative cases | Includes negative, edge and high-risk tasks |
| LLM-as-a-judge | Model scoring another model response | Calibrate against human labels |
| Coverage | Portion of cases system attempts/answers | Must compare error rate at chosen coverage |

## Knowledge, security and provenance
| Term | Meaning | Practical implication |
|---|---|---|
| Source of truth | Authorized definitive record | Orders/balance from business API, not model guess |
| Chunk | Search-indexed text segment | Preserve headings/section/version |
| Embedding | Vector representation of text/image | Similarity ≠ permission or fact correctness |
| Hybrid retrieval | Multiple retrieval methods combined | Keyword IDs + dense semantic paraphrases |
| Reranker | Initial candidate relevance re-scorer | Quality vs latency cost |
| Recall@k | Required relevant items found in top k | Missing evidence diagnosis |
| nDCG | Relevance rank quality metric | Ranking judged against graded labels |
| ACL | Access control list/policy | Filter before prompt/LLM exposure |
| Provenance | Evidence ka origin, version, time | Auditable citations |
| Tenant isolation | One customer organization's data separated | Scope in DB, retrieval, cache, logs |
| Prompt injection | Untrusted text tries to redirect system behavior | Never promote retrieved instructions to authority |
| Least privilege | Minimum tool/data permissions | Read-only by default |
| Idempotency | Repeat same write request should not duplicate effect | Use key + authoritative transaction status |
| Human approval | Explicit person authorizes exact action | Bind to parameters, actor, expiry |

## Inference, caching and operations
| Term | Meaning | Practical implication |
|---|---|---|
| TTFT | Time to first model output token | Perceived responsiveness |
| TPOT | Time per generated output token | Streaming speed indicator; define measurement |
| TBT | Gap between consecutive output tokens | Smoothness |
| p95 | 95th percentile of sample latency | 95% observed samples at/below value |
| Prefill | Processing input prompt tokens before decoding | Long context increases workload |
| Decode | Generating new tokens autoregressively | Long output impacts time and cost |
| Batching | Grouping work to use inference hardware efficiently | Throughput vs queue delay |
| Quantization | Lower-precision representation | Test quality/latency on own hardware |
| Exact cache | Answer reused for identical scoped request | Key must include relevant auth/data versions |
| Semantic cache | Similar-intent requests reuse answer | May be semantically close but legally different |
| Retrieval cache | Search results reused | Stale index/ACL risk |
| Prompt/KV cache | Shared model computation reused | Provider/engine-specific |
| TTL | Time to live of cached item | Does not guarantee instant invalidation |
| Circuit breaker | Temporarily stop repeated calls to unhealthy service | Prevent cascading failures |
| Exponential backoff | Retry wait grows with attempt count | Add jitter and retry budget |
| DLQ | Dead-letter queue for failed async jobs | Needs review/replay policy |
| Trace/span | Request flow and measured sub-steps | Debug slow/faulty paths |
| Drift | Traffic/model/data pattern changes over time | Trigger re-evaluation |
| Canary | Release to small traffic slice first | Quick rollback |
| RTO/RPO | Restoration time / tolerated data-loss window | Recovery planning |

## Useful formulas (all approximate and with assumptions)

**Average QPS:** `Requests per day / 86,400` (daily time-zone/peak behavior irrelevant in this average).

**In-flight requests (Little's Law):** `Average arrival rate × average time in system` for stable conditions. Peak capacity needs bursts and queue modeling.

**Nominal hosted model cost:** `(input tokens / 1,000,000) × price_per_1M_input + (output tokens / 1,000,000) × price_per_1M_output`. Add infrastructure, tools, retries, evaluation, storage and operations for true cost.

**Cache hit rate:** `Cache hits / cache-eligible reads`. Don't misrepresent as all requests if only a subset is eligible.

**Recall@k:** `Relevant items retrieved among top k / all relevant items` for a labeled query, then aggregate appropriately.

**p95 latency:** 95% of measured observations fall at/below this value. **Sum of per-stage p95 is not automatically end-to-end p95**.

**Sequential critical path:** Sum dependent stages. **Parallel critical path:** Maximum of independent branches plus join/coordination overhead.

**Expected cascade model cost (simple):** `Cost of first model + escalation probability × cost of second model` (validator and retry overhead excluded). For user latency, sequential escalation has extra cost in time too.

## 5 universal interview questions
1. **Why this design?** Requirement/metric ke saath map karo.
2. **What if it fails?** Per component failure behavior.
3. **How fast at scale?** Measured p95, QPS, token counts, queue.
4. **How do you know it's accurate?** Labeled eval, user outcomes, citation checks.
5. **Why not alternative X?** Trade-off and evidence; revisit threshold.
