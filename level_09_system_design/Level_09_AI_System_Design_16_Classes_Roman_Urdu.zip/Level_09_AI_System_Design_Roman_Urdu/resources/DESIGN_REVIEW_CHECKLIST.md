# Architect Review Checklist — har AI system par use karo

## A. Product clarity
- [ ] Users, workflows, non-goals explicit.
- [ ] Failure severity and privacy risks classified.
- [ ] Measurable task completion and accuracy criteria defined.
- [ ] Traffic, burst, token/context lengths, geographic/data constraints estimated.
- [ ] Assumptions marked and data collection plan set.

## B. Minimum design and technology selection
- [ ] Simple baseline measured against held-out eval.
- [ ] Prompt vs RAG vs live tools vs agent vs fine-tune chosen by actual need.
- [ ] Critical facts have authoritative source and provenance.
- [ ] Every service/component has explicit responsibility and contract.
- [ ] At least 3 alternatives rejected with evidence.

## C. Quality and information
- [ ] Document ingestion/index updating versioned and observable.
- [ ] Tenant ACL enforced *before* retrieval and tool access.
- [ ] Keyword + vector + graph justified by data and evaluation.
- [ ] Context bounded, metadata/citations preserved.
- [ ] Missing/conflicting evidence triggers abstention/handoff.

## D. Models and infrastructure
- [ ] Gateway route by task/risk/capability, not hardcoded brand loyalty.
- [ ] Fallback compatible with output schema and privacy rules.
- [ ] Sequential cascades evaluated for tail latency and cost.
- [ ] Realistic request-volume/TPM/RPM / capacity forecasts.
- [ ] Performance measured end-to-end with p95 tail behavior.
- [ ] Cache authorization scope/freshness and invalidation clear.

## E. Reliability and security
- [ ] Timeouts, retries, jitter, circuit breaker, backpressure documented.
- [ ] Side-effecting operations have idempotency + definitive status lookup.
- [ ] High-impact actions subject to explicit, parameter-bound approval.
- [ ] Retrieved content never authorizes a tool action.
- [ ] Degraded mode never substitutes guesses for live data.
- [ ] Logs/metrics/traces don't indiscriminately collect sensitive content.

## F. Production improvement
- [ ] Version IDs tracked for model, prompt, data index, policies, route.
- [ ] Quality, latency, error, cost, retrieval and safety dashboards.
- [ ] Explicit + implicit feedback measured with bias considered.
- [ ] Incident-to-regression-test process, canary and rollback plan.
- [ ] Ownership/alerting and feedback-review cadence documented.

## G. Interview presentation order

1. Clarifying questions (assumptions clear).
2. FR/NFR + SLO and major risks.
3. Baseline and simplest viable architecture.
4. Data flow / Mermaid diagram, access boundaries.
5. Model/context decisions and fallbacks.
6. Peak scale, latency budget, cost estimates.
7. Failure modes, monitoring, rollout, rejected alternatives.

### Decision record mini-template

**Decision name:** ...

**Context:** ...

**Constraints:** ...

**Options:** A ... B ... C ...

**Chosen:** ...

**Measured evidence / assumption:** ...

**Why rejected alternatives:** ...

**New risks and mitigations:** ...

**Revisit when:** ...

**Owner/version/date:** ...
