# Level 09 — AI System Design | Complete Roman Urdu Notes

> **Learning mode:** concept-first, no unnecessary Python implementation. 16 standalone Markdown classes, 10 original roadmap modules, diagrams, real-world decisions, trade-offs, practice questions, and a worked design-document capstone.

## Is course ka maqsad

AI Engineering ka matlab sirf LLM ko API se call karna nahi. Is course ke baad aap requirements se architecture tak ka safar justify kar sakein: **kyun RAG? kis model par? kaunsi requests cache? fallback kab? privacy kis boundary par? latency/cost aur answer quality kaise measure karni hai?**

**Primary syllabus:** [AI Engineer Roadmap 2026, Level 9](https://ai-engineer-roadmap-2026.vercel.app/level/9/). Roadmap par 10 modules aur 16 sessions diye gaye hain. Is course ki class mapping bilkul usi order mein hai.

**Reference book:** Chip Huyen, *AI Engineering: Building Applications with Foundation Models* (O’Reilly; user-provided PDF). Khaas chapters: Ch 4 (evaluation), Ch 5 (prompting + attacks), Ch 6 (RAG/agents), Ch 9 (inference optimization), Ch 10 (architecture, monitoring, user feedback). Book ke framing ko preserve karte hue **original Roman Urdu explanation aur independently constructed examples** likhe gaye hain. Ye book ka verbatim translation nahi.

## Class schedule / Contents

| Class | Module | Markdown file | Skill |
|---:|---|---|---|
| 01 | M9.1 | [01](classes/01_requirements_constraints.md) | Requirements, constraints, traffic, non-functional design |
| 02 | M9.1 | [02](classes/02_baseline_and_tradeoffs.md) | Baseline; prompting vs RAG vs agent vs fine-tune; decisions |
| 03 | M9.2 | [03](classes/03_knowledge_source_architecture.md) | Knowledge sources, memory, freshness, provenance |
| 04 | M9.2 | [04](classes/04_context_retrieval_pipeline.md) | Ingestion→retrieve→rerank→assemble, hybrid, ACL |
| 05 | M9.3 | [05](classes/05_gateway_and_routing.md) | Gateway, task/risk/cost-based routing |
| 06 | M9.3 | [06](classes/06_model_cascades_and_fallbacks.md) | Cascades, provider fallback, governance |
| 07 | M9.4 | [07](classes/07_latency_budget_and_streaming.md) | Latency waterfall, TTFT, streaming, SLO |
| 08 | M9.4 | [08](classes/08_parallelism_throughput_inference.md) | Parallel work, batching, throughput, utilization |
| 09 | M9.5 | [09](classes/09_caching_architecture.md) | Four caches, invalidation, semantic-cache risk |
| 10 | M9.6 | [10](classes/10_failure_modes_and_recovery.md) | Timeout/retry/queue/circuit breaker/degradation |
| 11 | M9.6 | [11](classes/11_guardrails_approval_slos.md) | Security boundaries, approval, service levels |
| 12 | M9.7 | [12](classes/12_pipeline_orchestration.md) | Sync/async/jobs, workflows, orchestration contracts |
| 13 | M9.8 | [13](classes/13_monitoring_feedback_iteration.md) | Logs/traces/evals/feedback/drift/versions |
| 14 | M9.9 | [14](classes/14_case_study_support_copilot.md) | Customer support copilot complete design |
| 15 | M9.9 | [15](classes/15_case_studies_coding_research.md) | Coding assistant and deep research agent |
| 16 | M9.10 | [16](classes/16_capstone_design_document.md) | Fully worked capstone + reusable template |

## Kaise parhna hai

1. Har class mein **Goal → concepts → architecture → trade-offs → common failure → exercise → answer key** follow karo.
2. Mermaid diagrams render karne ke liye VS Code Markdown Preview ka Mermaid support ya [mermaid.live](https://mermaid.live/) use kar sakte ho. Mermaid diagram sirf logical architecture samjhata hai, deployable code nahi.
3. Khud se diagram aur decision record banao: technology ka naam likhna enough nahi, us technology ko choose karne ka **evidence** chahiye.
4. Har class ke akhir mein exercises ka jawab diye baghair aglay class par na jao. Sample answers sirf reference hain; multiple well-justified designs valid ho sakte hain.
5. Class 16 ka capstone apni requirements se modify kar ke end-to-end architecture review ya interview mein present karo.

## Scenario jo poore course mein repeat hota hai

**Acme Support Copilot (fictional case study):** Multi-tenant SaaS company, knowledge base, account/order lookup, human handoff, privacy constraints, fast replies. Ye illustrative example hai; metrics aur dollar figures agar diye hon to **design assumptions** hain, verified industry benchmarks nahi.

## Resource directory

- [Glossary](resources/GLOSSARY.md): Roman Urdu definitions, formulas.
- [Coverage matrix](resources/ROADMAP_COVERAGE_MATRIX.md): official Level 9 bullets → class mapping.
- [Architect checklist](resources/DESIGN_REVIEW_CHECKLIST.md): reusable review sheet.
- [Book reading map](resources/BOOK_READING_MAP.md): source-grounded recommended chapters.

## Completion definition

Level 9 tab complete samjho jab aap bina code ke **requirements**, **baseline**, **data flow**, **model choices**, **cache policies**, **security**, **failure handling**, **measurable objectives**, **monitoring**, **cost assumptions**, aur **rejected alternatives** ka coherent document defend kar sako. Agla natural step Level 10 LLMOps hai, jahan is design ko production-operational workflow mein implement kiya jata hai.

*Note: Yahan kisi vendor, model, ya price ko immutable truth nahi maana gaya. Production implementation mein current model pricing, residency, auth limits, aur SLAs alag verify karna hota hai.*
