# Level 9 Study Tracker (Roman Urdu)

Is tracker mein class tab check karo jab **concept explain**, **diagram khud draw**, aur **practice ka answer justify** kar sako. Sirf file parh lena mastery nahi.

| Done | Class | Aap kis sawal ka jawab confidently de sakte hain? |
|---|---|---|
| [ ] | 01 | Vague product ask ko measurable FR/NFR/traffic mein kaise badlein? |
| [ ] | 02 | Prompt/RAG/tool/agent/fine-tune ka justified selection kaise? |
| [ ] | 03 | Authoritative facts RAG/memory/tool mein kahan se aate hain? |
| [ ] | 04 | Hybrid retrieval+ACL+reranking pipeline aur eval kaise? |
| [ ] | 05 | Gateway aur router ka boundary kya? |
| [ ] | 06 | Cascade vs fallback aur silent quality failure kya? |
| [ ] | 07 | p95 total latency aur TTFT ko kaise diagnose karein? |
| [ ] | 08 | Parallelism/throughput/batching ke trade-offs kya hain? |
| [ ] | 09 | Cache safety, TTL, ACL, invalidation and hit rate kya? |
| [ ] | 10 | Partial failure aur duplicate write kaise prevent? |
| [ ] | 11 | Prompt-level guardrails aur server authorization kyun different? |
| [ ] | 12 | Deterministic workflow aur agent ka decision kab? |
| [ ] | 13 | Deployment regression ko trace aur eval se kaise diagnose? |
| [ ] | 14 | Support copilot architecture end-to-end defend kar sakte? |
| [ ] | 15 | Coding assistant vs research agent architecture mein difference? |
| [ ] | 16 | Capstone document with alternatives and measurable goals ready? |

## Har class ke baad self-review
- [ ] Main concept 2-minute Roman Urdu explanation mein bol sakta hoon.
- [ ] Mermaid diagram dekhe baghair boxes/flows draw kar sakta hoon.
- [ ] Kam se kam 2 choices aur unke trade-offs justify kiye.
- [ ] Ek privacy/failure case explain kiya.
- [ ] Practice exercise khud attempt ki; sample answer se compare kiya.

## Final interview mock
**Question:** 20 tenants, 1M documents, 100k queries/day, p95 ≤5 sec, source citations, live orders, regional privacy constraints. Answer in this order: requirements → baseline → diagram → context/RAG → model gateway → fallback → latency/cost estimate → failure matrix → security → monitoring → rejected alternatives. Numeric assumptions clearly label karo. Kisi vendor ko sirf popularity ki wajah se choose na karo.
